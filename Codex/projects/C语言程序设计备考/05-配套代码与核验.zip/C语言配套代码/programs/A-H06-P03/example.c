#include <stdio.h>
#include <stdlib.h>

struct Node { int value; struct Node *next; };
static void destroy(struct Node *head)
{
    while (head != NULL) {
        struct Node *next = head->next;
        free(head);
        head = next;
    }
}
static int append(struct Node **head, struct Node **tail, int value)
{
    struct Node *p = malloc(sizeof *p);
    if (p == NULL) return 0;
    p->value = value; p->next = NULL;
    if (*tail != NULL) (*tail)->next = p;
    else *head = p;
    *tail = p;
    return 1;
}
static void print_list(const struct Node *head)
{
    if (head == NULL) { puts("EMPTY"); return; }
    for (const struct Node *p = head; p != NULL; p = p->next)
        printf("%d%s", p->value, p->next == NULL ? "\n" : " ");
}
static int remove_all(struct Node **head, int target)
{
    struct Node **link = head;
    int count = 0;
    while (*link != NULL) {
        if ((*link)->value == target) {
            struct Node *victim = *link;
            *link = victim->next;
            free(victim);
            ++count;
        } else {
            link = &(*link)->next;
        }
    }
    return count;
}

int main(void)
{
    int n;
    struct Node *head = NULL, *tail = NULL;
    if (scanf("%d", &n) != 1 || n < 0 || n > 20) { puts("INVALID"); return 1; }
    for (int i = 0; i < n; ++i) {
        int value;
        if (scanf("%d", &value) != 1) { puts("INVALID"); destroy(head); return 1; }
        if (!append(&head, &tail, value)) { puts("ALLOC_FAIL"); destroy(head); return 1; }
    }
    int target;
    if (scanf("%d", &target) != 1) { puts("INVALID"); destroy(head); return 1; }
    int deleted = remove_all(&head, target);
    printf("%d\n", deleted);
    print_list(head);
    destroy(head);
    return 0;
}
