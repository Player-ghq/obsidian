#include <stdio.h>
int main(void)
{
    int a = 6;
    int b = 11;
    int *p = &a;
    int **pp = &p;
    **pp += 4;
    *pp = &b;
    **pp -= 2;
    int *refs[2] = {&a, &b};
    printf("a=%d b=%d target=%d\n", *refs[0], *refs[1], *p);
    return 0;
}
