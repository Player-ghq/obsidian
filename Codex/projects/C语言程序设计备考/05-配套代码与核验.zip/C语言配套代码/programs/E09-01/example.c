#include <stdio.h>
#include <math.h>
int main(void) {
    printf("cos=%.2f\n", cos(0.0));
    printf("sqrt=%.2f\n", sqrt(9.0));
    printf("pow=%.2f\n", pow(2.0, 3.0));
    printf("exp=%.2f\n", exp(0.0));
    printf("fabs=%.2f\n", fabs(-2.5));
    printf("log=%.2f\n", log(1.0));
    printf("log10=%.2f\n", log10(100.0));
    return 0;
}
