#include <stdio.h>
int main(void) {
    FILE *fp = fopen("input.txt", "r");
    if (fp == NULL) return 1;
    size_t lines = 0;
    int ch, last = '\n';
    while ((ch = fgetc(fp)) != EOF) {
        if (ch == '\n') ++lines;
        last = ch;
    }
    int bad = ferror(fp);
    if (last != '\n') ++lines;
    if (fclose(fp) == EOF) bad = 1;
    if (bad) return 1;
    printf("lines=%zu\n", lines);
    return 0;
}
