#include <stdio.h>
int main(void)
{
    int n, a[20], key;
    if (scanf("%d", &n) != 1 || n < 0 || n > 20) {
        puts("invalid");
        return 1;
    }
    for (int i = 0; i < n; i++) {
        if (scanf("%d", &a[i]) != 1 || a[i] < -1000 || a[i] > 1000) {
            puts("invalid");
            return 1;
        }
    }
    if (scanf("%d", &key) != 1 || key < -1000 || key > 1000) {
        puts("invalid");
        return 1;
    }
    for (int i = 1; i < n; i++) {
        int value = a[i];
        int j = i;
        while (j > 0 && a[j - 1] > value) {
            a[j] = a[j - 1];
            j--;
        }
        a[j] = value;
    }
    for (int i = 0; i < n; i++) {
        if (i > 0) {
            putchar(' ');
        }
        printf("%d", a[i]);
    }
    putchar('\n');
    int found = -1;
    for (int i = 0; i < n; i++) {
        if (a[i] == key) {
            found = i;
            break;
        }
    }
    printf("%d\n", found);
    return 0;
}
