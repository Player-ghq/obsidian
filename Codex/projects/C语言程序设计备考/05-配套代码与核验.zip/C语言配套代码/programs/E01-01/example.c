#include <stdio.h>

int main(void)
{
    int count = 3;
    int price = 8;
    int total = count * price;
    printf("total=%d\n", total);
    return 0;
}
