#include <stdio.h>


int main(void)
{
    int a[2][3] = {{1,2,3},{4,5,6}};
    for (int c = 0; c < 3; ++c) {
        int sum = 0;
        for (int r = 0; r < 2; ++r) sum += a[r][c];
        printf("%d\n", sum);
    }
    return 0;
}
