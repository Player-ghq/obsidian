#include <stdio.h>
int next(void)
{
    static int n = 0;
    n++;
    return n;
}
int main(void)
{
    printf("%d\n", next());
    printf("%d\n", next());
    return 0;
}
