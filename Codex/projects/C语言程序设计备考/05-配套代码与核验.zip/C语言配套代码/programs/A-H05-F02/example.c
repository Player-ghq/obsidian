#include <stdio.h>
#include <stddef.h>

struct Text { char s[4]; char *p; };

int main(void)
{
    struct Text a = {"abc", NULL}, b;
    a.p = a.s + 1;
    ptrdiff_t offset = a.p - a.s;
    b = a;
    b.p = b.s + offset;
    *b.p = 'X';
    printf("%s %s\n", a.s, b.s);
    return 0;
}
