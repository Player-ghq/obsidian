#include <stdio.h>

static int next(void)
{
    static int count = 0;
    return ++count;
}

int main(void)
{
    int count = 100;
    int a = next();
    int b = next();
    printf("%d %d %d\n", a, b, count);
    return 0;
}
