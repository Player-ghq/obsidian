#include <stdio.h>
int main(void)
{
    int a = 3, b = 9;
    int temp = a;
    a = b;
    b = temp;
    printf("%d %d\n", a, b);
    return 0;
}
