#include <stdio.h>
#include <math.h>
int main(void) {
    double x;
    if (scanf("%lf", &x) != 1 || !isfinite(x) || x <= 0.0 || x > 1000000.0) {
        puts("INVALID"); return 0;
    }
    printf("%.3f %.3f %.3f\n", sqrt(x), log(x), log10(x));
    return 0;
}
