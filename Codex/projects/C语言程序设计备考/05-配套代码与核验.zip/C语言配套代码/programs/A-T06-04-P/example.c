#include <stdio.h>
#include <stddef.h>
int square(int x)
{
    return x * x;
}
int negate(int x)
{
    return -x;
}
void transform(int a[], size_t n, int (*fn)(int))
{
    for (size_t i = 0; i < n; ++i) a[i] = fn(a[i]);
}
void print_values(const int a[], size_t n)
{
    for (size_t i = 0; i < n; ++i) {
        printf("%s%d", i == 0 ? "" : " ", a[i]);
    }
    putchar('\n');
}
int main(void)
{
    int a[] = {1,-2,3};
    transform(a, 3, square);
    print_values(a, 3);
    transform(a, 3, negate);
    print_values(a, 3);
    return 0;
}
