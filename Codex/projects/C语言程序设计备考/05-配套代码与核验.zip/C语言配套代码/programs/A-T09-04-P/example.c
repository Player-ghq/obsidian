#include <stdio.h>
#include <string.h>
int main(void) {
    char a[32], b[32];
    if (scanf("%31s%31s", a, b) != 2) { puts("INVALID"); return 0; }
    printf("%zu %zu\n", strlen(a), strlen(b));
    int cmp = strcmp(a, b);
    if (cmp < 0) puts("LESS");
    else if (cmp == 0) puts("EQUAL");
    else puts("GREATER");
    return 0;
}
