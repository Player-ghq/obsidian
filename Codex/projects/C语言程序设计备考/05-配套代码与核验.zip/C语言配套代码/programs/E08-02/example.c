#include <stdio.h>
#include <stdlib.h>
struct Node { int value; struct Node *next; };
static void destroy(struct Node *head) {
    while (head != NULL) {
        struct Node *next = head->next;
        free(head);
        head = next;
    }
}
static int append(struct Node **head, struct Node **tail, int value) {
    struct Node *node = malloc(sizeof *node);
    if (node == NULL) return 0;
    node->value = value;
    node->next = NULL;
    if (*tail == NULL) *head = node;
    else (*tail)->next = node;
    *tail = node;
    return 1;
}
int main(void) {
    struct Node *head = NULL, *tail = NULL;
    int values[3] = {3, -1, 5};
    for (int i = 0; i < 3; ++i) {
        if (!append(&head, &tail, values[i])) {
            puts("ALLOC_FAIL"); destroy(head); return 1;
        }
    }
    int count = 0, sum = 0;
    for (const struct Node *p = head; p != NULL; p = p->next) {
        ++count;
        sum += p->value;
    }
    printf("count=%d sum=%d\n", count, sum);
    printf("head=%d\n", head->value);
    destroy(head);
    return 0;
}
