#include <stdio.h>
#include <stddef.h>

const int *find_negative(const int a[], size_t n)
{
    for (size_t i = 0; i < n; ++i) {
        if (a[i] < 0) return &a[i];
    }
    return NULL;
}

int main(void)
{
    int first[] = {4, 0, -7, -2};
    int second[] = {1, 2, 3};
    const int *p = find_negative(first, 4);
    if (p != NULL) printf("first=%d\n", *p);
    p = find_negative(second, 3);
    if (p == NULL) puts("second=none");
    return 0;
}
