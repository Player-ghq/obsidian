#include <stdio.h>
#include <stdlib.h>
struct Node { int value; struct Node *next; };
static void destroy(struct Node *head) {
    while (head != NULL) {
        struct Node *next = head->next;
        free(head);
        head = next;
    }
}
static int append(struct Node **head, struct Node **tail, int value) {
    struct Node *node = malloc(sizeof *node);
    if (node == NULL) return 0;
    node->value = value;
    node->next = NULL;
    if (*tail == NULL) *head = node;
    else (*tail)->next = node;
    *tail = node;
    return 1;
}
static void print_list(const struct Node *head) {
    if (head == NULL) { puts("EMPTY"); return; }
    for (const struct Node *p = head; p != NULL; p = p->next) {
        printf("%d%s", p->value, p->next == NULL ? "\n" : " ");
    }
}
static int read_list(struct Node **head, struct Node **tail) {
    int n;
    if (scanf("%d", &n) != 1 || n < 0 || n > 10) return 0;
    for (int i = 0; i < n; ++i) {
        int value;
        if (scanf("%d", &value) != 1 || value < -1000 || value > 1000) return 0;
        if (!append(head, tail, value)) return -1;
    }
    return 1;
}
static int delete_first(struct Node **head, int target) {
    struct Node **link = head;
    while (*link != NULL && (*link)->value != target) {
        link = &(*link)->next;
    }
    if (*link == NULL) return 0;
    struct Node *victim = *link;
    *link = victim->next;
    free(victim);
    return 1;
}
int main(void) {
    struct Node *head = NULL, *tail = NULL;
    int status = read_list(&head, &tail);
    if (status != 1) {
        puts(status == 0 ? "INVALID" : "ALLOC_FAIL");
        destroy(head);
        return status == 0 ? 0 : 1;
    }
    int target;
    if (scanf("%d", &target) != 1 || target < -1000 || target > 1000) {
        puts("INVALID"); destroy(head); return 0;
    }
    puts(delete_first(&head, target) ? "DELETED" : "NOT_FOUND");
    print_list(head);
    destroy(head);
    return 0;
}
