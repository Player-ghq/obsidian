#include <stdio.h>
#include <stddef.h>

struct Record { int id, score; };
static const struct Record *find(const struct Record a[], size_t n, int cutoff)
{
    for (size_t i = 0; i < n; ++i) if (a[i].score >= cutoff) return &a[i];
    return NULL;
}

int main(void)
{
    struct Record a[] = {{10,70},{20,90}};
    const struct Record *p = find(a,2,85);
    if (p != NULL) printf("%d %d\n", p->id, p->score);
    p = find(a,2,95);
    if (p == NULL) puts("NONE");
    return 0;
}
