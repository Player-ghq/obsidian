#include <stdio.h>
int main(void)
{
    char names[2][8] = {"Li", "Wang"};
    const char *roles[] = {"runner", "coach"};
    names[0][0] = 'Q';
    roles[1] = "judge";
    for (size_t i = 0; i < 2; ++i) {
        printf("%s:%s\n", names[i], roles[i]);
    }
    return 0;
}
