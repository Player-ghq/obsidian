#include <stdio.h>

int main(void)
{
    int a = 2, b = 3, c = 4;
    int result = a + b * c;
    a = b = 5;
    {
        int extra = 1;
        result += extra;
    }
    printf("%d %d %d\n", result, a, b);
    return 0;
}
