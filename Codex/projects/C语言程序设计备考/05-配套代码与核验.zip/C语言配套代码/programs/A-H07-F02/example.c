#include <stdio.h>
#include <string.h>


int main(void)
{
    FILE *fp=fopen("input.txt","r");
    if (fp==NULL) return 1;
    char line[64];
    size_t number=0;
    int bad=0;
    while (fgets(line, sizeof line, fp) != NULL) {
        if (printf("%zu:",++number)<0 || fputs(line, stdout) == EOF) { bad=1; break; }
        if (strchr(line,'\n')==NULL && putchar('\n')==EOF) { bad=1; break; }
    }
    if (ferror(fp)) bad=1;
    if (fclose(fp)!=0) bad=1;
    if (fflush(stdout)==EOF) bad=1;
    return bad;
}
