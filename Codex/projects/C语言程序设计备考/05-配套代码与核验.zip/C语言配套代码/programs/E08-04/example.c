#include <stdio.h>
#include <stdlib.h>
struct Node { int value; struct Node *next; };
static void destroy(struct Node *head) {
    while (head != NULL) {
        struct Node *next = head->next;
        free(head);
        head = next;
    }
}
static int append(struct Node **head, struct Node **tail, int value) {
    struct Node *node = malloc(sizeof *node);
    if (node == NULL) return 0;
    node->value = value;
    node->next = NULL;
    if (*tail == NULL) *head = node;
    else (*tail)->next = node;
    *tail = node;
    return 1;
}
static void print_list(const struct Node *head) {
    if (head == NULL) { puts("EMPTY"); return; }
    for (const struct Node *p = head; p != NULL; p = p->next) {
        printf("%d%s", p->value, p->next == NULL ? "\n" : " ");
    }
}
static int delete_first(struct Node **head, int target) {
    struct Node **link = head;
    while (*link != NULL && (*link)->value != target) {
        link = &(*link)->next;
    }
    if (*link == NULL) return 0;
    struct Node *victim = *link;
    *link = victim->next;
    free(victim);
    return 1;
}
int main(void) {
    struct Node *head = NULL, *tail = NULL;
    int values[3] = {5, 8, 5};
    for (int i = 0; i < 3; ++i) {
        if (!append(&head, &tail, values[i])) {
            puts("ALLOC_FAIL"); destroy(head); return 1;
        }
    }
    printf("deleted=%d\n", delete_first(&head, 5));
    print_list(head);
    destroy(head);
    return 0;
}
