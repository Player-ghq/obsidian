#include <stdio.h>
#include <limits.h>

static int add_checked(int a, int b, int *result)
{
    if ((b > 0 && a > INT_MAX - b) || (b < 0 && a < INT_MIN - b)) return 0;
    *result = a + b;
    return 1;
}

int main(void)
{
    int result = 9;
    int ok = add_checked(INT_MAX, 1, &result);
    printf("%d %d\n", ok, result);
    ok = add_checked(INT_MAX, -1, &result);
    printf("%d\n", ok && result == INT_MAX - 1);
    return 0;
}
