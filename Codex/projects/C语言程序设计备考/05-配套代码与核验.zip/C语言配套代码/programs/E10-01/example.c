#include <stdio.h>
int main(void) {
    int n;
    double price;
    int result = scanf("%d %lf", &n, &price);
    if (result != 2) {
        if (result == EOF) puts("No input");
        else printf("Invalid input: assigned=%d\n", result);
        return 1;
    }
    printf("n=%d price=%.2f total=%.2f\n", n, price, n * price);
    return 0;
}
