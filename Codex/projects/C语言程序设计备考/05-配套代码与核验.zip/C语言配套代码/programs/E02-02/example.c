#include <stdio.h>

int main(void)
{
    int total = 12, people = 0;
    int possible = people != 0 && total / people >= 3;
    int a = 8, b = 5;
    int maximum = a > b ? a : b;
    printf("%d %d %d\n", possible, maximum, !maximum);
    return 0;
}
