#include <stdio.h>
int main(void) {
    int count;
    double mass;
    if (scanf("%d %lf", &count, &mass) != 2) { puts("Invalid"); return 1; }
    printf("count=%d mass=%.1f\n", count, mass);
    return 0;
}
