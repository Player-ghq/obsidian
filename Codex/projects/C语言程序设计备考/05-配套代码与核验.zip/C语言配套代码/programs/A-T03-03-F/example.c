#include <stdio.h>
int main(void)
{
    for (int i = 1; i <= 4; i++) {
        if (i == 2) {
            continue;
        }
        printf("%d\n", i);
    }
    return 0;
}
