#include <stdio.h>
#include <string.h>
int main(void)
{
    const char *words[] = {"run", "swim", "cycle", "walk"};
    size_t n = sizeof words / sizeof words[0];
    size_t best = 0;
    for (size_t i = 1; i < n; ++i) {
        if (strlen(words[i]) > strlen(words[best])) best = i;
    }
    printf("%s %zu\n", words[best], strlen(words[best]));
    return 0;
}
