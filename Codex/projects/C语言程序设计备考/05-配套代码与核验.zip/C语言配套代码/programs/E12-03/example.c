#include <stdio.h>
static size_t linear_find(const int a[], size_t n, int target) {
    for (size_t i = 0; i < n; ++i) if (a[i] == target) return i;
    return n;
}
static size_t lower_bound(const int a[], size_t n, int target) {
    size_t low = 0, high = n;
    while (low < high) {
        size_t mid = low + (high - low) / 2;
        if (a[mid] < target) low = mid + 1;
        else high = mid;
    }
    return low;
}
int main(void) {
    const int a[] = {1, 3, 3, 7, 9};
    size_t n = sizeof a / sizeof a[0];
    int target;
    if (scanf("%d", &target) != 1) return 1;
    size_t p = lower_bound(a, n, target);
    printf("linear=%zu lower=%zu\n", linear_find(a, n, target), p);
    if (p < n && a[p] == target) printf("found=%zu\n", p);
    else puts("Not found");
    return 0;
}
