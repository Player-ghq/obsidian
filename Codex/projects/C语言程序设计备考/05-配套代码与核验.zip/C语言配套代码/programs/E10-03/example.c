#include <stdio.h>
int main(void) {
    FILE *fp = fopen("scores.txt", "w");
    if (fp == NULL) { puts("Open error"); return 1; }
    int bad = fprintf(fp, "80 90 100\n") < 0;
    if (fclose(fp) == EOF) bad = 1;
    if (bad) { puts("Write error"); return 1; }
    fp = fopen("scores.txt", "r");
    if (fp == NULL) { puts("Open error"); return 1; }
    int value, count = 0, sum = 0, result;
    while ((result = fscanf(fp, "%d", &value)) == 1) {
        sum += value;
        ++count;
    }
    bad = ferror(fp) || result != EOF;
    if (fclose(fp) == EOF) bad = 1;
    if (bad) { puts("Read/format error"); return 1; }
    printf("count=%d sum=%d\n", count, sum);
    return 0;
}
