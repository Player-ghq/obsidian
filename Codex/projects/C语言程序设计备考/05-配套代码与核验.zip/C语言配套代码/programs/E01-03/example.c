#include <stdio.h>

int main(void)
{
    int stock = 5;
    double price = 2.5;
    char grade = 'A';
    const int sold = 2;
    stock = stock - sold;
    double value = stock * price;
    printf("%c %d %.2f\n", grade, stock, value);
    return 0;
}
