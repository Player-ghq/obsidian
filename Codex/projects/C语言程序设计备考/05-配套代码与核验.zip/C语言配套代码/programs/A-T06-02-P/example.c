#include <stdio.h>
#include <stddef.h>
void minmax(const int a[], size_t n, int *low, int *high)
{
    *low = a[0];
    *high = a[0];
    for (size_t i = 1; i < n; ++i) {
        if (a[i] < *low) *low = a[i];
        if (a[i] > *high) *high = a[i];
    }
}
int main(void)
{
    int a[] = {-3,7,0,7};
    int one[] = {5};
    int low, high;
    minmax(a, 4, &low, &high);
    printf("min=%d max=%d\n", low, high);
    minmax(one, 1, &low, &high);
    printf("min=%d max=%d\n", low, high);
    return 0;
}
