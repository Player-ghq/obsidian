#include "stats.h"
static int sum = 0;
static int count = 0;
void record(int value) { sum += value; ++count; }
int sum_value(void) { return sum; }
int record_count(void) { return count; }
