#ifndef STUDY_STATS_H
#define STUDY_STATS_H
void record(int value);
int sum_value(void);
int record_count(void);
#endif
