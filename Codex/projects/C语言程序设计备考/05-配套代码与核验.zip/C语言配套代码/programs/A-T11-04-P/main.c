#include <stdio.h>
#include "stats.h"
int main(void) {
    int a, b;
    if (scanf("%d %d", &a, &b) != 2 || a < 0 || a > 100 || b < 0 || b > 100) return 1;
    record(a);
    record(b);
    printf("sum=%d count=%d\n", sum_value(), record_count());
    return 0;
}
