#include <stdio.h>


int main(void)
{
    char text[] = "banana";
    char *read = text, *write = text;
    while (*read != '\0') {
        if (*read != 'a') *write++ = *read;
        ++read;
    }
    *write = '\0';
    puts(text);
    return 0;
}
