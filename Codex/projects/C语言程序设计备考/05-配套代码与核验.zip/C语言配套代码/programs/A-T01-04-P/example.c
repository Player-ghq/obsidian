#include <stdio.h>
int next_ticket(void)
{
    static int ticket = 100;
    ticket++;
    return ticket;
}
int main(void)
{
    printf("%d\n", next_ticket());
    printf("%d\n", next_ticket());
    printf("%d\n", next_ticket());
    return 0;
}
