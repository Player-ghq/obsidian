#include <stdio.h>
int main(void)
{
    unsigned int flags = 10U;
    flags |= 1U;
    printf("%u\n", flags);
    flags ^= 8U;
    printf("%u\n", flags);
    flags &= ~2U;
    printf("%u\n", flags);
    return 0;
}
