#include <stdio.h>
#include <string.h>
int main(void)
{
    char text[16];
    if (fgets(text, sizeof text, stdin) == NULL) {
        puts("input error");
        return 1;
    }
    text[strcspn(text, "\n")] = '\0';
    printf("capacity=%zu length=%zu text=[%s]\n",
           sizeof text, strlen(text), text);
    return 0;
}
