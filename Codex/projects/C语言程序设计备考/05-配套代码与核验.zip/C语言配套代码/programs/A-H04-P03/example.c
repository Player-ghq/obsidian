#include <stdio.h>

static void evaluate(const double a[], int degree, double x,
                     double *value, double *derivative)
{
    double p = a[0], d = 0;
    for (int i = 1; i <= degree; ++i) {
        d = d * x + p;
        p = p * x + a[i];
    }
    *value = p;
    *derivative = d;
}

int main(void)
{
    int degree;
    double x, a[7];
    if (scanf("%d%lf", &degree, &x) != 2 || degree < 0 || degree > 6 || x < -3 || x > 3) { puts("INVALID"); return 1; }
    for (int i = 0; i <= degree; ++i) if (scanf("%lf", &a[i]) != 1 || a[i] < -10 || a[i] > 10) { puts("INVALID"); return 1; }
    double value, derivative;
    evaluate(a, degree, x, &value, &derivative);
    printf("%.2f %.2f\n", value, derivative);
    return 0;
}
