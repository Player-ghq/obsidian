#include <stdio.h>

int main(void)
{
    int sum = 0;
    for (int i = 1; i <= 9; i++) {
        if (i == 7) {
            break;
        }
        if (i % 2 == 0) {
            continue;
        }
        sum += i;
    }
    printf("%d\n", sum);
    return 0;
}
