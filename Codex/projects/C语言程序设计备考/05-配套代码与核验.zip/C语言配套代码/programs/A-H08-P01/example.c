#include <stdio.h>


int main(void)
{
    int n, a[30];
    if (scanf("%d", &n) != 1 || n < 0 || n > 30) { puts("INVALID"); return 1; }
    for (int i = 0; i < n; ++i) if (scanf("%d", &a[i]) != 1) { puts("INVALID"); return 1; }
    for (int i = 1; i < n; ++i) {
        int key = a[i], j = i;
        while (j > 0 && a[j-1] > key) { a[j] = a[j-1]; --j; }
        a[j] = key;
    }
    int maximum = 0;
    for (int i = 0; i < n;) {
        int j = i + 1;
        while (j < n && a[j] == a[i]) ++j;
        if (j - i > maximum) maximum = j - i;
        i = j;
    }
    printf("frequency=%d\n", maximum);
    int first = 1;
    for (int i = 0; i < n;) {
        int j = i + 1;
        while (j < n && a[j] == a[i]) ++j;
        if (j - i == maximum) { printf("%s%d", first ? "" : " ", a[i]); first = 0; }
        i = j;
    }
    putchar('\n');
    return 0;
}
