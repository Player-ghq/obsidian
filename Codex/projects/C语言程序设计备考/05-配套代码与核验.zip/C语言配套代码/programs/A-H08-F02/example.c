#include <stdio.h>


int main(void)
{
    int a[]={1,1,2,2,2,4};
    int n=6;
    int used=n > 0 ? 1 : 0;
    for (int i=1;i<n;++i) if (a[i] != a[used - 1]) a[used++]=a[i];
    for (int i=0;i<used;++i) printf("%s%d",i?" ":"",a[i]);
    putchar('\n');
    return 0;
}
