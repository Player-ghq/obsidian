#include <stdio.h>
#include <stdlib.h>

struct Node { int value; struct Node *next; };
static void destroy(struct Node *head)
{
    while (head != NULL) {
        struct Node *next = head->next;
        free(head);
        head = next;
    }
}
static int append(struct Node **head, struct Node **tail, int value)
{
    struct Node *p = malloc(sizeof *p);
    if (p == NULL) return 0;
    p->value = value; p->next = NULL;
    if (*tail != NULL) (*tail)->next = p;
    else *head = p;
    *tail = p;
    return 1;
}
static void print_list(const struct Node *head)
{
    if (head == NULL) { puts("EMPTY"); return; }
    for (const struct Node *p = head; p != NULL; p = p->next)
        printf("%d%s", p->value, p->next == NULL ? "\n" : " ");
}
static struct Node *merge(struct Node *a, struct Node *b)
{
    struct Node dummy = {0, NULL};
    struct Node *tail = &dummy;
    while (a != NULL && b != NULL) {
        if (a->value <= b->value) { tail->next = a; a = a->next; }
        else { tail->next = b; b = b->next; }
        tail = tail->next;
    }
    tail->next = a != NULL ? a : b;
    return dummy.next;
}

int main(void)
{
    int n, m;
    struct Node *a = NULL, *at = NULL, *b = NULL, *bt = NULL;
    if (scanf("%d%d", &n, &m) != 2 || n < 0 || n > 20 || m < 0 || m > 20) { puts("INVALID"); return 1; }
    for (int which = 0; which < 2; ++which) {
        int length = which == 0 ? n : m;
        struct Node **head = which == 0 ? &a : &b;
        struct Node **tail = which == 0 ? &at : &bt;
        for (int i = 0; i < length; ++i) {
            int value;
            if (scanf("%d", &value) != 1 || (*tail != NULL && value < (*tail)->value)) {
                puts("INVALID"); destroy(a); destroy(b); return 1;
            }
            if (!append(head, tail, value)) { puts("ALLOC_FAIL"); destroy(a); destroy(b); return 1; }
        }
    }
    struct Node *merged = merge(a, b);
    print_list(merged);
    destroy(merged);
    return 0;
}
