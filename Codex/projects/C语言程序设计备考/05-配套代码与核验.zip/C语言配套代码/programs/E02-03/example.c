#include <stdio.h>

int main(void)
{
    unsigned int flags = 5U;
    flags |= 2U;
    printf("%u\n", flags);
    flags &= ~1U;
    printf("%u\n", flags);
    flags ^= 4U;
    printf("%u %d\n", flags, (flags & 2U) != 0U);
    printf("%u %u\n", 3U << 1, 6U >> 1);
    return 0;
}
