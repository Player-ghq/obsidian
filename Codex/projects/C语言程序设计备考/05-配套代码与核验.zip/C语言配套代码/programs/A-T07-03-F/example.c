#include <stdio.h>
struct Date { int year; int month; };
struct Record { char name[8]; struct Date date; };
int main(void) {
    struct Record r = {"May", {2026, 9}};
    struct Record *p = &r;
    p->date.month = 10;
    printf("%s %d\n", p->name, p->date.month);
    return 0;
}
