#include <stdio.h>
#define RATE 2
#define SQUARE(x) ((x) * (x))
static int square(int x) { return x * x; }
int main(void) {
    int a = 3;
    printf("macro=%d\n", SQUARE(a + 1));
    printf("function=%d\n", square(a++));
    printf("a=%d rate=%d\n", a, RATE);
    return 0;
}
