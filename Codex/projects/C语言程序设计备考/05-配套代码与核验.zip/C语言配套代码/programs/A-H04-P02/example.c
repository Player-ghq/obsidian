#include <stdio.h>

static void count_digits(unsigned long n, unsigned int counts[10])
{
    if (n == 0) return;
    ++counts[n % 10UL];
    count_digits(n / 10UL, counts);
}

int main(void)
{
    unsigned long n;
    if (scanf("%lu", &n) != 1 || n > 1000000000UL) { puts("INVALID"); return 1; }
    unsigned int counts[10] = {0};
    if (n == 0) counts[0] = 1;
    else count_digits(n, counts);
    for (int i = 0; i < 10; ++i) printf("%s%u", i ? " " : "", counts[i]);
    putchar('\n');
    return 0;
}
