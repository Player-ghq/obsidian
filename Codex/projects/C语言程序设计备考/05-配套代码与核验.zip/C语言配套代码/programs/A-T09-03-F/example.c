#include <stdio.h>
#include <string.h>
int main(void) {
    char out[12] = "";
    strcpy(out, "sun");
    strcat(out, "rise");
    printf("%s\n", out);
    return 0;
}
