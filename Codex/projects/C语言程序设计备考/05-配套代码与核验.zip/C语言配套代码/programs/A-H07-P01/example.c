#include <stdio.h>
int main(int argc, char *argv[])
{
    if (argc != 2) { puts("INVALID"); return 1; }
    FILE *fp = fopen(argv[1], "r");
    if (fp == NULL) { puts("INVALID"); return 1; }
    size_t counts[10] = {0}, lines = 0, longest = 0, current = 0, bytes = 0;
    int ch, last = '\n', bad = 0;
    while ((ch = fgetc(fp)) != EOF) {
        if (++bytes > 10000) { bad = 1; break; }
        if (ch >= '0' && ch <= '9') ++counts[ch - '0'];
        if (ch == '\n') {
            ++lines;
            if (current > longest) longest = current;
            current = 0;
        } else ++current;
        last = ch;
    }
    if (bytes > 0 && last != '\n') {
        ++lines;
        if (current > longest) longest = current;
    }
    if (ferror(fp)) bad = 1;
    if (fclose(fp) != 0) bad = 1;
    if (bad) { puts("INVALID"); return 1; }
    printf("lines=%zu longest=%zu\n", lines, longest);
    for (int i = 0; i < 10; ++i) printf("%s%zu", i ? " " : "", counts[i]);
    putchar('\n');
    if (fflush(stdout) == EOF) return 1;
    return 0;
}
