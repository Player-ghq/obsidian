#include <stdio.h>

static int even(int x) { return x % 2 == 0; }
static int positive(int x) { return x > 0; }
static int one_digit(int x) { return x >= -9 && x <= 9; }
static int filter(int a[], int n, int (*keep)(int))
{
    int used = 0;
    for (int i = 0; i < n; ++i) if (keep(a[i])) a[used++] = a[i];
    return used;
}

int main(void)
{
    int mode, n, a[30];
    if (scanf("%d%d", &mode, &n) != 2 || mode < 1 || mode > 3 || n < 0 || n > 30) { puts("INVALID"); return 1; }
    for (int i = 0; i < n; ++i) if (scanf("%d", &a[i]) != 1) { puts("INVALID"); return 1; }
    int (*rules[3])(int) = {even, positive, one_digit};
    int used = filter(a, n, rules[mode - 1]);
    printf("%d\n", used);
    for (int i = 0; i < used; ++i) printf("%s%d", i ? " " : "", a[i]);
    putchar('\n');
    return 0;
}
