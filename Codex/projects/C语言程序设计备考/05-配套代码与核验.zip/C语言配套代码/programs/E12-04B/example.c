#include <stdio.h>
#include <limits.h>
int main(void) {
    unsigned int value, base;
    if (scanf("%u %u", &value, &base) != 2 || base < 2 || base > 16) return 1;
    const char digits[] = "0123456789ABCDEF";
    char out[sizeof(unsigned int) * CHAR_BIT + 1];
    size_t used = 0;
    do {
        out[used++] = digits[value % base];
        value /= base;
    } while (value != 0);
    while (used > 0) putchar(out[--used]);
    putchar('\n');
    return 0;
}
