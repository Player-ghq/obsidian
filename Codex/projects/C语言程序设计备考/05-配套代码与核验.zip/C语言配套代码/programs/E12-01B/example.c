#include <stdio.h>
static void selection_sort(int a[], size_t n) {
    for (size_t i = 0; i < n; ++i) {
        size_t min_index = i;
        for (size_t j = i + 1; j < n; ++j)
            if (a[j] < a[min_index]) min_index = j;
        if (min_index != i) {
            int t = a[i]; a[i] = a[min_index]; a[min_index] = t;
        }
    }
}
int main(void) {
    int a[] = {4, 1, 3, 1};
    size_t n = sizeof a / sizeof a[0];
    selection_sort(a, n);
    for (size_t i = 0; i < n; ++i) printf("%s%d", i ? " " : "", a[i]);
    putchar('\n');
    selection_sort(a, 0);
    return 0;
}
