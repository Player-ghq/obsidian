#include <stdio.h>
#include <stdlib.h>
struct Box { int value; };
int main(void) {
    struct Box *p = malloc(sizeof *p);
    if (p == NULL) {
        puts("ALLOC_FAIL");
        return 1;
    }
    p->value = 42;
    printf("value=%d\n", p->value);
    free(p);
    p = NULL;
    printf("cleared=%d\n", p == NULL);
    return 0;
}
