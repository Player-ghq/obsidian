#include <stdio.h>
int minimum(int a, int b);
int main(void)
{
    printf("%d\n", minimum(8, 3));
    return 0;
}
int minimum(int a, int b)
{
    if (a < b) return a;
    return b;
}
