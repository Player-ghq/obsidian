#include <stdio.h>
int main(void) {
    int n, a[20], value;
    if (scanf("%d", &n) != 1 || n < 0 || n > 19) return 1;
    for (int i = 0; i < n; ++i) {
        if (scanf("%d", &a[i]) != 1 || (i > 0 && a[i] < a[i - 1])) return 1;
    }
    if (scanf("%d", &value) != 1) return 1;
    int j = n;
    while (j > 0 && a[j - 1] > value) { a[j] = a[j - 1]; --j; }
    a[j] = value;
    for (int i = 0; i <= n; ++i) printf("%s%d", i ? " " : "", a[i]);
    putchar('\n');
    return 0;
}
