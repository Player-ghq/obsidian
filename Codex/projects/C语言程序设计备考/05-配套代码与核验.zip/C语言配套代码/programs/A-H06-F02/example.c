#include <stdio.h>

struct Node { int value; struct Node *next; };

int main(void)
{
    struct Node c={3,NULL}, b={2,&c}, a={1,&b};
    struct Node *head=&a;
    struct Node **link=&head;
    while (*link != NULL && (*link)->value != 2) link = &(*link)->next;
    if (*link != NULL) *link = (*link)->next;
    for (struct Node *p=head; p!=NULL; p=p->next) printf("%d%s",p->value,p->next?" ":"\n");
    return 0;
}
