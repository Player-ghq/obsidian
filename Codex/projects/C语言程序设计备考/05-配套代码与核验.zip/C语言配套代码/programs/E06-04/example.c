#include <stdio.h>

int add(int a, int b)
{
    return a + b;
}

int max2(int a, int b)
{
    return a > b ? a : b;
}

void show(const char *label, int value)
{
    printf("%s=%d\n", label, value);
}

int main(void)
{
    int (*op)(int, int) = add;
    show("add", op(4, 7));
    op = max2;
    show("max", (*op)(4, 7));
    return 0;
}
