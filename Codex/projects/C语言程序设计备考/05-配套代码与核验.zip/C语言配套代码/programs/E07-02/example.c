#include <stdio.h>
struct Item { int code; int quantity; };
int main(void) {
    struct Item a[3] = {{10, 2}, {20, 3}, {30, 4}};
    struct Item *p = &a[1];
    p->quantity += 2;
    int total = 0;
    for (int i = 0; i < 3; ++i) {
        total += a[i].quantity;
        printf("%d:%d\n", a[i].code, a[i].quantity);
    }
    printf("total=%d\n", total);
    return 0;
}
