#include <stdio.h>
int main(void) {
    const double coefficients[] = {2, -3, 0, 5};
    double x;
    if (scanf("%lf", &x) != 1 || x < -10 || x > 10) return 1;
    double value = coefficients[0];
    size_t count = sizeof coefficients / sizeof coefficients[0];
    for (size_t i = 1; i < count; ++i) value = value * x + coefficients[i];
    printf("P(%.2f)=%.2f\n", x, value);
    return 0;
}
