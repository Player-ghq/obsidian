#include <stdio.h>
unsigned int sum_to(unsigned int n)
{
    if (n == 0) return 0;
    return n + sum_to(n - 1);
}
int main(void)
{
    printf("%u %u\n", sum_to(0), sum_to(3));
    return 0;
}
