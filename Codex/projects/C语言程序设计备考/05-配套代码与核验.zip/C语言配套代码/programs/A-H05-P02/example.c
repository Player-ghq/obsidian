#include <stdio.h>

struct Item { int id, quantity; };

int main(void)
{
    int n, used = 0;
    struct Item a[20];
    if (scanf("%d", &n) != 1 || n < 0 || n > 20) { puts("INVALID"); return 1; }
    for (int i = 0; i < n; ++i) {
        int id, quantity;
        if (scanf("%d%d", &id, &quantity) != 2 || id < 1 || id > 9999 || quantity < 0 || quantity > 1000) { puts("INVALID"); return 1; }
        int j = 0;
        while (j < used && a[j].id != id) ++j;
        if (j == used) { a[used].id = id; a[used].quantity = 0; ++used; }
        a[j].quantity += quantity;
    }
    for (int i = 0; i < used; ++i) {
        int min = i;
        for (int j = i + 1; j < used; ++j) if (a[j].id < a[min].id) min = j;
        struct Item temp = a[i]; a[i] = a[min]; a[min] = temp;
    }
    if (used == 0) puts("EMPTY");
    for (int i = 0; i < used; ++i) printf("%d %d\n", a[i].id, a[i].quantity);
    return 0;
}
