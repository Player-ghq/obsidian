#include <stdio.h>
#include <stdlib.h>
struct Cell { int value; };
int main(void) {
    int n;
    if (scanf("%d", &n) != 1 || n < 0 || n > 10) {
        puts("INVALID"); return 0;
    }
    if (n == 0) { puts("sum=0"); return 0; }
    struct Cell *a = malloc((size_t)n * sizeof *a);
    if (a == NULL) { puts("ALLOC_FAIL"); return 1; }
    int sum = 0;
    for (int i = 0; i < n; ++i) {
        a[i].value = i + 1;
        sum += a[i].value;
    }
    printf("sum=%d\n", sum);
    free(a);
    return 0;
}
