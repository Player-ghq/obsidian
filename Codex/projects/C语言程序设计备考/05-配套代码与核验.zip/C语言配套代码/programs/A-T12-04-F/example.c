#include <stdio.h>
int main(void) {
    const double a[] = {3, 0, -2, 1};
    double x = 2, value = a[0];
    for (size_t i = 1; i < 4; ++i) value = value * x + a[i];
    printf("%.0f\n", value);
    return 0;
}
