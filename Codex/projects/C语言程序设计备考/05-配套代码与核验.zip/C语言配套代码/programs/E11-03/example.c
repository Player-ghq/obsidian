#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <limits.h>
int main(int argc, char *argv[]) {
    if (argc != 3) { puts("Usage: add INTEGER INTEGER"); return 1; }
    int values[2];
    for (int i = 0; i < 2; ++i) {
        char *end;
        errno = 0;
        long v = strtol(argv[i + 1], &end, 10);
        if (end == argv[i + 1] || *end != '\0' || errno == ERANGE || v < INT_MIN || v > INT_MAX) {
            puts("Invalid integer"); return 1;
        }
        values[i] = (int)v;
    }
    int a = values[0], b = values[1];
    if ((b > 0 && a > INT_MAX - b) || (b < 0 && a < INT_MIN - b)) {
        puts("Sum out of range"); return 1;
    }
    printf("sum=%d\n", a + b);
    return 0;
}
