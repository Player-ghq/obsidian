#include <stdio.h>

int increase_copy(int x);
int square(int x);

int main(void)
{
    int n = 5;
    int changed = increase_copy(n);
    int squared = square(n);
    printf("n=%d changed=%d squared=%d\n", n, changed, squared);
    return 0;
}

int increase_copy(int x)
{
    x += 2;
    return x;
}

int square(int x)
{
    return x * x;
}
