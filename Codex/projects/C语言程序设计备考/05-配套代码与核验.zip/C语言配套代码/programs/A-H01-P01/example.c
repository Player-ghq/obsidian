#include <stdio.h>


int main(void)
{
    int a, b;
    char op;
    if (scanf("%d %c %d", &a, &op, &b) != 3 || a < -1000 || a > 1000 || b < -1000 || b > 1000) {
        puts("INVALID"); return 1;
    }
    long result;
    switch (op) {
        case '+': result = (long)a + b; break;
        case '-': result = (long)a - b; break;
        case '*': result = (long)a * b; break;
        case '/':
        case '%':
            if (b == 0) { puts("INVALID"); return 1; }
            result = op == '/' ? a / b : a % b;
            break;
        default: puts("INVALID"); return 1;
    }
    printf("%ld\n", result);
    return 0;
}
