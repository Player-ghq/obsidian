#include <stdio.h>
#include <string.h>
#include <stddef.h>

struct Text { char data[32]; char *mark; };
static void clone(struct Text *destination, const struct Text *source)
{
    ptrdiff_t offset = source->mark - source->data;
    *destination = *source;
    destination->mark = destination->data + offset;
}

int main(void)
{
    struct Text a, b;
    int offset;
    char replacement;
    if (scanf("%31s%d %c", a.data, &offset, &replacement) != 3 || offset < 0 || (size_t)offset >= strlen(a.data)) { puts("INVALID"); return 1; }
    a.mark = a.data + offset;
    clone(&b, &a);
    *b.mark = replacement;
    printf("%s\n%s\n%s\n%s\n", a.data, b.data, a.mark, b.mark);
    return 0;
}
