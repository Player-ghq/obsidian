#include <stdio.h>
int main(void)
{
    int n;
    if (scanf("%d", &n) != 1 || n < 0 || n > 100) {
        puts("invalid");
        return 1;
    }
    long sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += (long)i * i;
    }
    printf("%ld\n", sum);
    return 0;
}
