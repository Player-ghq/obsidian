#include <stdio.h>
int main(void)
{
    int n;
    if (scanf("%d", &n) != 1 || n < 1 || n > 9) {
        puts("invalid");
        return 1;
    }
    for (int row = 1; row <= n; row++) {
        for (int col = 1; col <= row; col++) {
            printf("%d", col);
        }
        putchar('\n');
    }
    return 0;
}
