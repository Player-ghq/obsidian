#include <stdio.h>
#include <stddef.h>
const int *find_value(const int a[], size_t n, int target)
{
    for (size_t i = 0; i < n; ++i) {
        if (a[i] == target) return &a[i];
    }
    return NULL;
}
int main(void)
{
    int a[] = {4,8,4};
    const int *p = find_value(a, 3, 4);
    if (p != NULL) printf("found=%d\n", *p);
    if (find_value(a, 3, 7) == NULL) puts("missing");
    if (find_value(a, 0, 4) == NULL) puts("empty");
    return 0;
}
