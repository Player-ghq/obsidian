#include <stdio.h>
int main(void) {
    int n, a[20], target;
    if (scanf("%d", &n) != 1 || n < 0 || n > 20) return 1;
    for (int i = 0; i < n; ++i) {
        if (scanf("%d", &a[i]) != 1 || (i > 0 && a[i] < a[i - 1])) return 1;
    }
    if (scanf("%d", &target) != 1) return 1;
    int low = 0, high = n;
    while (low < high) {
        int mid = low + (high - low) / 2;
        if (a[mid] < target) low = mid + 1;
        else high = mid;
    }
    if (low < n && a[low] == target) printf("index=%d\n", low);
    else puts("Not found");
    return 0;
}
