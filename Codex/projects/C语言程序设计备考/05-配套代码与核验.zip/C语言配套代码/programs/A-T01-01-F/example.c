#include <stdio.h>
int main(void)
{
    int a = 4, b = 6;
    printf("%d\n", a * b); /* 输出乘积 */
    return 0;
}
