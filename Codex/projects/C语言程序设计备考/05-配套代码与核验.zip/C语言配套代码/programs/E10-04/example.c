#include <stdio.h>
int main(void) {
    FILE *in = fopen("input.txt", "r");
    if (in == NULL) { puts("Open error"); return 1; }
    FILE *out = fopen("copy.txt", "w");
    if (out == NULL) { fclose(in); puts("Open error"); return 1; }
    int ch, bad = 0;
    size_t count = 0;
    while ((ch = fgetc(in)) != EOF) {
        if (fputc(ch, out) == EOF) { bad = 1; break; }
        ++count;
    }
    if (ferror(in)) bad = 1;
    int ended = feof(in) != 0;
    if (fclose(in) == EOF) bad = 1;
    if (fclose(out) == EOF) bad = 1;
    if (bad) { puts("I/O error"); return 1; }
    printf("characters=%zu eof=%d\n", count, ended);
    return 0;
}
