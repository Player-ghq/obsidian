#include <stdio.h>
int main(void) {
    int a[3];
    for (int i = 0; i < 3; ++i)
        if (scanf("%d", &a[i]) != 1 || a[i] < 0 || a[i] > 100) return 1;
    FILE *fp = fopen("saved.txt", "w");
    if (fp == NULL) return 1;
    int bad = fprintf(fp, "%d %d %d\n", a[0], a[1], a[2]) < 0;
    if (fclose(fp) == EOF) bad = 1;
    if (bad) return 1;
    fp = fopen("saved.txt", "r");
    if (fp == NULL) return 1;
    int value, maximum = 0;
    for (int i = 0; i < 3; ++i) {
        if (fscanf(fp, "%d", &value) != 1) { fclose(fp); return 1; }
        if (i == 0 || value > maximum) maximum = value;
    }
    if (fclose(fp) == EOF) return 1;
    printf("max=%d\n", maximum);
    return 0;
}
