#include <stdio.h>
#include <string.h>
int main(void)
{
    char words[3][8] = {"sun", "moon", "star"};
    for (size_t i = 0; i < 3; ++i) printf("%zu\n", strlen(words[i]));
    return 0;
}
