#include <stdio.h>
#include <ctype.h>
int main(void) {
    int ch = getchar();
    if (ch == EOF) { puts("EMPTY"); return 0; }
    printf("%c\n", toupper(ch));
    return 0;
}
