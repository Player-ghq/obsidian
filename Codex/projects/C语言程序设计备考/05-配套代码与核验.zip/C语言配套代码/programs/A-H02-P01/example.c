#include <stdio.h>


int main(void)
{
    int n, a[30];
    if (scanf("%d", &n) != 1 || n < 0 || n > 30) { puts("INVALID"); return 1; }
    for (int i = 0; i < n; ++i) if (scanf("%d", &a[i]) != 1) { puts("INVALID"); return 1; }
    int used = 0;
    for (int i = 0; i < n; ++i) {
        int j = 0;
        while (j < used && a[j] != a[i]) ++j;
        if (j == used) a[used++] = a[i];
    }
    printf("%d\n", used);
    for (int i = 0; i < used; ++i) printf("%s%d", i ? " " : "", a[i]);
    putchar('\n');
    return 0;
}
