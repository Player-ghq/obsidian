#include <stdio.h>
#include <math.h>
int main(void) {
    double x = 16.0;
    double y = -3.5;
    printf("%.1f %.1f\n", sqrt(x), fabs(y));
    return 0;
}
