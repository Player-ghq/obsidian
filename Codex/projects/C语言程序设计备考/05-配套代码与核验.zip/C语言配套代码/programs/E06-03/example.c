#include <stdio.h>

unsigned long long factorial(unsigned int n)
{
    if (n == 0) return 1;
    return n * factorial(n - 1);
}

void report(unsigned int n)
{
    unsigned long long value = factorial(n);
    printf("%u!=%llu\n", n, value);
}

int main(void)
{
    report(4);
    report(0);
    return 0;
}
