#include <stdio.h>
int main(void) {
    const unsigned char source[] = {0, 10, 255};
    unsigned char target[3];
    FILE *fp = fopen("bytes.bin", "wb");
    if (fp == NULL) return 1;
    int bad = fwrite(source, 1, sizeof source, fp) != sizeof source;
    if (fclose(fp) == EOF) bad = 1;
    if (bad) return 1;
    fp = fopen("bytes.bin", "rb");
    if (fp == NULL) return 1;
    bad = fread(target, 1, sizeof target, fp) != sizeof target;
    if (fclose(fp) == EOF) bad = 1;
    if (bad) return 1;
    printf("%u %u %u\n", (unsigned)target[0], (unsigned)target[1], (unsigned)target[2]);
    return 0;
}
