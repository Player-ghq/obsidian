#include <stdio.h>
#include <limits.h>

static int parse(const char *text, unsigned long *out)
{
    unsigned long value=0;
    for (size_t i=0;text[i]!='\0';++i) {
        unsigned long digit=(unsigned long)(text[i]-'0');
        if (value > (ULONG_MAX - digit) / 10UL) return 0;
        value=value * 10UL + digit;
    }
    *out=value;
    return 1;
}

int main(void)
{
    unsigned long value=0;
    if (parse("123",&value)) printf("%lu\n",value);
    printf("%d\n",parse("9999999999999999999999999999999999999999",&value));
    return 0;
}
