#include <stdio.h>

int main(void)
{
    int score = 85;
    char level;
    if (score >= 90) {
        level = 'A';
    } else if (score >= 60) {
        level = 'B';
    } else {
        level = 'C';
    }
    switch (level) {
        case 'A': puts("excellent"); break;
        case 'B': puts("pass"); break;
        default: puts("retry"); break;
    }
    return 0;
}
