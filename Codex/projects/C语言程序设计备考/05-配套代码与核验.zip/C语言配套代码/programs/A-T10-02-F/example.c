#include <stdio.h>
#include <string.h>
int main(void) {
    char text[16];
    if (fgets(text, sizeof text, stdin) == NULL) return 1;
    size_t n = strlen(text);
    if (n > 0 && text[n - 1] == '\n') text[n - 1] = '\0';
    puts(text);
    return 0;
}
