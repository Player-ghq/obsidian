#include <stdio.h>
#include <string.h>


int main(void)
{
    char text[62], out[121];
    if (fgets(text, sizeof text, stdin) == NULL) { puts("INVALID"); return 1; }
    size_t n = strcspn(text, "\n");
    if (n > 60 || (text[n] != '\n' && !feof(stdin))) {
        puts("INVALID"); return 1;
    }
    text[n] = '\0';
    for (size_t i = 0; i < n; ++i) if (text[i] < 'a' || text[i] > 'z') { puts("INVALID"); return 1; }
    size_t used = 0;
    for (size_t i = 0; i < n;) {
        size_t j = i + 1;
        while (j < n && text[j] == text[i]) ++j;
        int wrote = snprintf(out + used, sizeof out - used, "%c%zu", text[i], j - i);
        if (wrote < 0 || (size_t)wrote >= sizeof out - used) { puts("INVALID"); return 1; }
        used += (size_t)wrote;
        i = j;
    }
    out[used] = '\0';
    puts(out);
    return 0;
}
