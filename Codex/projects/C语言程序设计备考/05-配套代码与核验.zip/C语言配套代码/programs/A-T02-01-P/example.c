#include <stdio.h>
int main(void)
{
    int a, b;
    if (scanf("%d%d", &a, &b) != 2 ||
        a < -1000 || a > 1000 || b < -1000 || b > 1000 || b == 0) {
        puts("invalid");
        return 1;
    }
    printf("%d %d %.2f\n", a / b, a % b, (double)a / b);
    return 0;
}
