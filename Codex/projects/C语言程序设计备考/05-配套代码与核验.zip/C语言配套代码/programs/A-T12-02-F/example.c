#include <stdio.h>
static void insertion_sort(int a[], size_t n) {
    for (size_t i = 1; i < n; ++i) {
        int key = a[i];
        size_t j = i;
        while (j > 0 && a[j - 1] > key) {
            a[j] = a[j - 1];
            --j;
        }
        a[j] = key;
    }
}
int main(void) {
    int a[] = {7, 3, 5, 3};
    size_t n = sizeof a / sizeof a[0];
    insertion_sort(a, n);
    for (size_t i = 0; i < n; ++i) printf("%s%d", i ? " " : "", a[i]);
    putchar('\n');
    insertion_sort(a, 0);
    return 0;
}
