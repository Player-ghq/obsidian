#include <stdio.h>
int main(void)
{
    int price = 12, count = 3;
    double discount = 0.8;
    double first = price * count * discount;
    double second = (price - 2) * count;
    printf("%.2f %.2f\n", first, second);
    return 0;
}
