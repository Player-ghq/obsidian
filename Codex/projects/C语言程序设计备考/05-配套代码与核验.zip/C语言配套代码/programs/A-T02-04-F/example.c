#include <stdio.h>
int main(void)
{
    unsigned int flags = 2U;
    if ((flags & 2U) != 0U) { /* 填带括号的位检测表达式 */
        puts("on");
    }
    return 0;
}
