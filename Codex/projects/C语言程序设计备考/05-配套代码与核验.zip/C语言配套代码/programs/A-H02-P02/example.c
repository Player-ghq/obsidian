#include <stdio.h>


int main(void)
{
    int a[3][4];
    for (int r = 0; r < 3; ++r) for (int c = 0; c < 4; ++c)
        if (scanf("%d", &a[r][c]) != 1) { puts("INVALID"); return 1; }
    int found = 0;
    for (int r = 0; r < 3; ++r) {
        int row_min = a[r][0];
        for (int c = 1; c < 4; ++c) if (a[r][c] < row_min) row_min = a[r][c];
        for (int c = 0; c < 4; ++c) {
            if (a[r][c] != row_min) continue;
            int okay = 1;
            for (int k = 0; k < 3; ++k) if (a[k][c] > a[r][c]) okay = 0;
            if (okay) { printf("%d %d %d\n", r, c, a[r][c]); found = 1; }
        }
    }
    if (!found) puts("NONE");
    return 0;
}
