#include <stdio.h>
struct Date { int year; int month; int day; };
struct Person {
    char name[16];
    const char *category;
    struct Date birthday;
};
int main(void) {
    struct Person a = {"Lin", "student", {2002, 5, 6}};
    struct Person b = a;
    b.name[0] = 'J';
    b.birthday.year = 2003;
    printf("%s %s %d\n", a.name, a.category, a.birthday.year);
    printf("%s %s %d\n", b.name, b.category, b.birthday.year);
    printf("shared=%d\n", a.category == b.category);
    return 0;
}
