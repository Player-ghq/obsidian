#include <stdio.h>

static long power(long x, unsigned int n)
{
    if (n == 0) return 1L;
    long half = power(x, n / 2);
    if (n % 2 != 0) return half * half * x;
    return half * half;
}

int main(void)
{
    printf("%ld %ld\n", power(2,10), power(2,0));
    return 0;
}
