#include <stdio.h>
int main(void)
{
    int a[] = {4, -1, 7, 7, 2, 0};
    size_t n = sizeof a / sizeof a[0];
    for (size_t i = 0; i < n / 2; ++i) {
        int temp = a[i];
        a[i] = a[n - 1 - i];
        a[n - 1 - i] = temp;
    }
    for (size_t i = 0; i < n; ++i) {
        printf("%s%d", i == 0 ? "" : " ", a[i]);
    }
    putchar('\n');
    return 0;
}
