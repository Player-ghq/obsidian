#include <stdio.h>
int main(void)
{
    int a[] = {-3, 9, 2, 7};
    int best = a[0];
    for (int i = 1; i < 4; i++) {
        if (a[i] > best) {
            best = a[i];
        }
    }
    printf("%d\n", best);
    return 0;
}
