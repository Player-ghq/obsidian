#include <stdio.h>
int main(void)
{
    int month;
    if (scanf("%d", &month) != 1 || month < 1 || month > 12) {
        puts("invalid");
        return 1;
    }
    int quarter;
    if (month <= 3) {
        quarter = 1;
    } else if (month <= 6) {
        quarter = 2;
    } else if (month <= 9) {
        quarter = 3;
    } else {
        quarter = 4;
    }
    printf("%d\n", quarter);
    return 0;
}
