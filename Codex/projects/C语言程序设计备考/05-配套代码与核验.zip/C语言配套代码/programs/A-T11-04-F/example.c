#include <stdio.h>
static int next_number(void) {
    static int count = 0;
    return ++count;
}
int main(void) {
    int first = next_number();
    int second = next_number();
    printf("%d %d\n", first, second);
    return 0;
}
