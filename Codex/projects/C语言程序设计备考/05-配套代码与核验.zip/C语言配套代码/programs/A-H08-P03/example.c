#include <stdio.h>


int main(void)
{
    int n, a[30];
    if (scanf("%d", &n) != 1 || n < 0 || n > 30) { puts("INVALID"); return 1; }
    for (int i = 0; i < n; ++i) if (scanf("%d", &a[i]) != 1) { puts("INVALID"); return 1; }
    long inversions = 0;
    for (int i = 1; i < n; ++i) {
        int key = a[i], j = i;
        while (j > 0 && a[j-1] > key) {
            a[j] = a[j-1]; --j; ++inversions;
        }
        a[j] = key;
    }
    printf("%ld\n", inversions);
    for (int i = 0; i < n; ++i) printf("%s%d", i ? " " : "", a[i]);
    putchar('\n');
    return 0;
}
