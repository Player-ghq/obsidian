#include <stdio.h>

int main(void)
{
    int sum_for = 0;
    for (int i = 1; i <= 3; i++) {
        sum_for += i;
    }
    int sum_while = 0, j = 1;
    while (j <= 3) {
        sum_while += j;
        j++;
    }
    int sum_do = 0, k = 1;
    do {
        sum_do += k;
        k++;
    } while (k <= 3);
    printf("%d %d %d\n", sum_for, sum_while, sum_do);
    return 0;
}
