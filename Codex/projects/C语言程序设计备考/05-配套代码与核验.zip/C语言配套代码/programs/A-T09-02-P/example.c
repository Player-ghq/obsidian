#include <stdio.h>
#include <ctype.h>
int main(void) {
    int ch;
    int alpha = 0, digit = 0, lower = 0;
    while ((ch = getchar()) != EOF && ch != '\n') {
        if (isalpha(ch)) ++alpha;
        if (isdigit(ch)) ++digit;
        if (islower(ch)) ++lower;
        putchar(toupper(ch));
    }
    putchar('\n');
    printf("alpha=%d digit=%d lower=%d\n", alpha, digit, lower);
    return 0;
}
