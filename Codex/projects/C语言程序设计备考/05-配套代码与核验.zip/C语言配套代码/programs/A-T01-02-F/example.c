#include <stdio.h>
#define RATE 1e2
int main(void)
{
    printf("%.1f\n", RATE); /* 输出100.0，空内要求科学记数法 */
    return 0;
}
