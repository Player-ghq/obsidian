#include <stdio.h>
int main(void)
{
    int value = 12;
    int *p = &value;
    *p += 3;
    printf("%d\n", value);
    return 0;
}
