#include <stdio.h>
int main(void)
{
    int initial = 8, incoming = 7, sold = 5;
    int remaining = initial + incoming - sold;
    printf("%d\n", remaining);
    return 0;
}
