#include <stdio.h>

struct Node { int value; struct Node *next; };

int main(void)
{
    struct Node d={4,NULL}, c={3,&d}, b={2,&c}, a={1,&b};
    struct Node *odd=NULL,*even=NULL;
    struct Node **ot=&odd, **et=&even;
    struct Node *p=&a;
    while (p != NULL) {
        struct Node *next=p->next;
        p->next=NULL;
        if (p->value % 2 != 0) { *ot = p; ot = &p->next; }
        else { *et=p; et=&p->next; }
        p=next;
    }
    for (struct Node *q=odd;q!=NULL;q=q->next) printf("%d%s",q->value,q->next?" ":"\n");
    for (struct Node *q=even;q!=NULL;q=q->next) printf("%d%s",q->value,q->next?" ":"\n");
    return 0;
}
