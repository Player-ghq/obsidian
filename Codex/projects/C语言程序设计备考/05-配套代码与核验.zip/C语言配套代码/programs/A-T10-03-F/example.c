#include <stdio.h>
int main(void) {
    FILE *fp = fopen("numbers.txt", "r");
    if (fp == NULL) return 1;
    int value, result, sum = 0;
    while ((result = fscanf(fp, "%d", &value)) == 1) sum += value;
    int bad = ferror(fp) || result != EOF;
    if (fclose(fp) == EOF) bad = 1;
    if (bad) { puts("Invalid"); return 1; }
    printf("sum=%d\n", sum);
    return 0;
}
