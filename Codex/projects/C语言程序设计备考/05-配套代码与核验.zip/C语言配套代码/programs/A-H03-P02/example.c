#include <stdio.h>

static void transpose(int (*a)[5], int n)
{
    for (int r = 0; r < n; ++r) {
        for (int c = r + 1; c < n; ++c) {
            int temp = a[r][c];
            a[r][c] = a[c][r];
            a[c][r] = temp;
        }
    }
}

int main(void)
{
    int a[5][5], n;
    if (scanf("%d", &n) != 1 || n < 1 || n > 5) { puts("INVALID"); return 1; }
    for (int r = 0; r < n; ++r) for (int c = 0; c < n; ++c)
        if (scanf("%d", &a[r][c]) != 1) { puts("INVALID"); return 1; }
    transpose(a, n);
    for (int r = 0; r < n; ++r) {
        for (int c = 0; c < n; ++c) printf("%s%d", c ? " " : "", a[r][c]);
        putchar('\n');
    }
    return 0;
}
