#include <stdio.h>
int main(void)
{
    int a = 6, b = 9;
    int smaller = a < b ? a : b;
    printf("%d\n", smaller);
    return 0;
}
