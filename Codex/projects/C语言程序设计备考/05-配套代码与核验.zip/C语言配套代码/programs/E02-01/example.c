#include <stdio.h>

int main(void)
{
    int a = 7, b = 3;
    double wrong = a / b;
    double average = (double)a / b;
    int i = 4;
    int old = i++;
    int now = ++i;
    printf("%d %d %.2f %.2f\n", a / b, a % b, wrong, average);
    printf("%d %d %d\n", old, now, i);
    return 0;
}
