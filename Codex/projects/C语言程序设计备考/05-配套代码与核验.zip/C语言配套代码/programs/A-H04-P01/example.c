#include <stdio.h>

static int first(const int a[], int lo, int hi, int key)
{
    if (lo > hi) return -1;
    int mid = lo + (hi - lo) / 2;
    if (a[mid] < key) return first(a, mid + 1, hi, key);
    if (a[mid] > key) return first(a, lo, mid - 1, key);
    int earlier = first(a, lo, mid - 1, key);
    return earlier == -1 ? mid : earlier;
}

int main(void)
{
    int n, a[30], key;
    if (scanf("%d", &n) != 1 || n < 0 || n > 30) { puts("INVALID"); return 1; }
    for (int i = 0; i < n; ++i) {
        if (scanf("%d", &a[i]) != 1 || (i > 0 && a[i] < a[i-1])) { puts("INVALID"); return 1; }
    }
    if (scanf("%d", &key) != 1) { puts("INVALID"); return 1; }
    printf("%d\n", first(a, 0, n - 1, key));
    return 0;
}
