#include <stdio.h>
int main(void)
{
    int sum = 0;
    for (int i = 1; i <= 5; i++) {
        sum += i;
    }
    printf("%d\n", sum); /* 计算1到5，输出15 */
    return 0;
}
