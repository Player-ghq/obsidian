#include <stdio.h>
#include <string.h>
int main(void) {
    char first[16], second[16], out[24];
    if (scanf("%15s%15s", first, second) != 2) {
        puts("INVALID"); return 0;
    }
    size_t needed = strlen(first) + 1 + strlen(second) + 1;
    if (needed > sizeof out) { puts("TOO_LONG"); return 0; }
    strcpy(out, first);
    strcat(out, "-");
    strcat(out, second);
    puts(out);
    return 0;
}
