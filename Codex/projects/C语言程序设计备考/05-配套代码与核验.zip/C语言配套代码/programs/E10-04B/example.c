#include <stdio.h>
#include <string.h>
int main(void) {
    FILE *fp = fopen("lines.txt", "r");
    if (fp == NULL) { puts("Open error"); return 1; }
    char line[80];
    size_t number = 0, hits = 0;
    int bad = 0;
    while (fgets(line, sizeof line, fp) != NULL) {
        ++number;
        if (strstr(line, "cat") != NULL) {
            printf("%zu:", number);
            if (fputs(line, stdout) == EOF) { bad = 1; break; }
            if (strchr(line, '\n') == NULL) putchar('\n');
            ++hits;
        }
    }
    if (ferror(fp) || ferror(stdout)) bad = 1;
    if (fclose(fp) == EOF) bad = 1;
    if (bad) return 1;
    printf("hits=%zu\n", hits);
    return 0;
}
