#include <stdio.h>
int main(void)
{
    int total = 7, count = 2;
    double mean = (double) total / count;
    printf("%.1f\n", mean);
    return 0;
}
