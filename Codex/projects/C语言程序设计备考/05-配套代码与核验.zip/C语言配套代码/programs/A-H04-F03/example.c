#include <stdio.h>

static unsigned int gcd(unsigned int a, unsigned int b)
{
    if (b == 0) return a;
    return gcd(b, a % b);
}

int main(void)
{
    printf("%u %u %u\n", gcd(18,24), gcd(0,9), gcd(0,0));
    return 0;
}
