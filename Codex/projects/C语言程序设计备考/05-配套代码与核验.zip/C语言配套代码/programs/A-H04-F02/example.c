#include <stdio.h>
#include <stddef.h>

static int total(const int *a, size_t n)
{
    if (n == 0) return 0;
    return a[0] + total(a + 1, n - 1);
}

int main(void)
{
    int a[] = {-1, 4, -2};
    printf("%d %d\n", total(a,3), total(a,0));
    return 0;
}
