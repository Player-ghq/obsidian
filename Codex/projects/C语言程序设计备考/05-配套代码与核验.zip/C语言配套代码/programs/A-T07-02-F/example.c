#include <stdio.h>
struct Ticket { int price; };
int main(void) {
    struct Ticket a[2] = {{20}, {30}};
    struct Ticket *p = &a[1];
    p->price += 5;
    printf("%d %d\n", a[0].price, a[1].price);
    return 0;
}
