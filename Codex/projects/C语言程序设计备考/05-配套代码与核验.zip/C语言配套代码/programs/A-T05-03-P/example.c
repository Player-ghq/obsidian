#include <stdio.h>
int main(void)
{
    int a = 7, b = 2, c = 5;
    int *refs[3] = {&a, &b, &c};
    for (size_t i = 0; i < 3; ++i) {
        for (size_t j = i + 1; j < 3; ++j) {
            if (*refs[j] < *refs[i]) {
                int *temp = refs[i];
                refs[i] = refs[j];
                refs[j] = temp;
            }
        }
    }
    printf("sorted=%d %d %d\n", *refs[0], *refs[1], *refs[2]);
    printf("original=%d %d %d\n", a, b, c);
    return 0;
}
