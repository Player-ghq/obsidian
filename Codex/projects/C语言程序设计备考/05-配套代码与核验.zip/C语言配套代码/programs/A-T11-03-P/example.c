#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
int main(int argc, char *argv[]) {
    if (argc != 3) { puts("Usage: repeat COUNT TEXT"); return 1; }
    errno = 0;
    char *end;
    long count = strtol(argv[1], &end, 10);
    if (end == argv[1] || *end != '\0' || errno == ERANGE || count < 0 || count > 5) {
        puts("Invalid count"); return 1;
    }
    for (long i = 0; i < count; ++i) puts(argv[2]);
    return 0;
}
