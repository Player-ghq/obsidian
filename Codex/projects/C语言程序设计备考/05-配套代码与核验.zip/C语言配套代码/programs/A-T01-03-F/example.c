#include <stdio.h>
int main(void)
{
    double price = 2.5;
    int count = 4;
    printf("%.2f\n", price * count);
    return 0;
}
