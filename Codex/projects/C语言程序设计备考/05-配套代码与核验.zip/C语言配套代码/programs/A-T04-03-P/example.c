#include <stdio.h>
int main(void)
{
    char text[64];
    if (fgets(text, sizeof text, stdin) == NULL) {
        puts("input error");
        return 1;
    }
    int digits = 0;
    int spaces = 0;
    for (size_t i = 0; text[i] != '\0'; ++i) {
        if (text[i] >= '0' && text[i] <= '9') ++digits;
        if (text[i] == ' ') ++spaces;
    }
    printf("digits=%d spaces=%d\n", digits, spaces);
    return 0;
}
