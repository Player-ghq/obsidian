#include <stdio.h>
int main(void)
{
    printf("%d %d %d\n", 31, 037, 0x1F);
    printf("\\\n");
    return 0;
}
