#include <stdio.h>
#include <string.h>
int main(void) {
    char out[16] = "";
    const char *first = "red";
    const char *second = "pen";
    if (strlen(first) >= sizeof out) { puts("TOO_LONG"); return 0; }
    strcpy(out, first);
    if (strlen("-") >= sizeof out - strlen(out)) { puts("TOO_LONG"); return 0; }
    strcat(out, "-");
    if (strlen(second) >= sizeof out - strlen(out)) { puts("TOO_LONG"); return 0; }
    strcat(out, second);
    printf("%s\n", out);
    printf("length=%zu capacity=%zu\n", strlen(out), sizeof out);
    return 0;
}
