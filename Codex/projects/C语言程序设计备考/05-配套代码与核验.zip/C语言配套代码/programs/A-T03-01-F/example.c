#include <stdio.h>
int main(void)
{
    int x = 0;
    if (x > 0) {
        puts("positive");
    } else if (x < 0) {
        puts("negative");
    } else {
        puts("zero");
    }
    return 0;
}
