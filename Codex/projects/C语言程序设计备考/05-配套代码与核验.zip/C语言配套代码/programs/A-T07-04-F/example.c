#include <stdio.h>
#include <stdlib.h>
struct Counter { int value; };
int main(void) {
    struct Counter *p = malloc(sizeof *p);
    if (p == NULL) { puts("ALLOC_FAIL"); return 1; }
    p->value = 7;
    printf("%d\n", p->value);
    free(p);
    return 0;
}
