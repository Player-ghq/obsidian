#include <stdio.h>
#include <string.h>
int main(void) {
    const char *a = "same";
    const char *b = "same";
    printf("length=%zu\n", strlen(a));
    if (strcmp(a, b) == 0) puts("SAME");
    return 0;
}
