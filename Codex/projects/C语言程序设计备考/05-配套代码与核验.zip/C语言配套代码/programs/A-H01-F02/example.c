#include <stdio.h>

#define LOW(n) ((1U << (n)) - 1U)

int main(void)
{
    printf("%u %u\n", LOW(2 + 1), LOW(1) << 2);
    return 0;
}
