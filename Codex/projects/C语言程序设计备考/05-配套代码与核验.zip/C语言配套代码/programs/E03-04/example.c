#include <stdio.h>

int main(void)
{
    for (int row = 1; row <= 3; row++) {
        for (int col = 1; col <= row; col++) {
            putchar('*');
        }
        putchar('\n');
    }
    return 0;
}
