#include <stdio.h>
int count_divisors(int n)
{
    int count = 0;
    for (int d = 1; d <= n; ++d) {
        if (n % d == 0) ++count;
    }
    return count;
}
int main(void)
{
    int cases[] = {1, 12, 13};
    for (size_t i = 0; i < sizeof cases / sizeof cases[0]; ++i) {
        printf("%d:%d\n", cases[i], count_divisors(cases[i]));
    }
    return 0;
}
