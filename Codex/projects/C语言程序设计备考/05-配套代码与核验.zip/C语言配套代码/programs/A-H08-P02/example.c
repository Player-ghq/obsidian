#include <stdio.h>

static int bound(const int a[], int n, int key, int upper)
{
    int low = 0, high = n;
    while (low < high) {
        int mid = low + (high - low) / 2;
        if (a[mid] < key || (upper && a[mid] == key)) low = mid + 1;
        else high = mid;
    }
    return low;
}

int main(void)
{
    int n, q, a[30], queries[10];
    if (scanf("%d", &n) != 1 || n < 0 || n > 30) { puts("INVALID"); return 1; }
    for (int i = 0; i < n; ++i) if (scanf("%d", &a[i]) != 1 || (i > 0 && a[i] < a[i-1])) { puts("INVALID"); return 1; }
    if (scanf("%d", &q) != 1 || q < 0 || q > 10) { puts("INVALID"); return 1; }
    for (int i = 0; i < q; ++i) if (scanf("%d", &queries[i]) != 1) { puts("INVALID"); return 1; }
    for (int i = 0; i < q; ++i) {
        int low = bound(a, n, queries[i], 0);
        int high = bound(a, n, queries[i], 1);
        if (low == high) puts("-1 -1 0");
        else printf("%d %d %d\n", low, high - 1, high - low);
    }
    return 0;
}
