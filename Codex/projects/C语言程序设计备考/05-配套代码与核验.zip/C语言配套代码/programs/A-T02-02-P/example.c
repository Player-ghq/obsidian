#include <stdio.h>
int main(void)
{
    int a = 8, b = -2, c = 5;
    int best = a > b ? a : b;
    best = best > c ? best : c;
    printf("%d\n", best);
    return 0;
}
