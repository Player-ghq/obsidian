#include <stdio.h>
int main(void)
{
    int score[2][3] = {{70, 80, 90}, {88, 92, 75}};
    for (size_t r = 0; r < 2; ++r) {
        int row_sum = 0;
        for (size_t c = 0; c < 3; ++c) {
            row_sum += score[r][c];
        }
        printf("student%zu=%d\n", r + 1, row_sum);
    }
    return 0;
}
