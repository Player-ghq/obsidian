#include <stdio.h>
struct Node {
    int value;
    struct Node *next;
};
int main(void)
{
    struct Node c = {6, NULL};
    struct Node b = {5, &c};
    struct Node a = {4, &b};
    struct Node *p = &a;
    while (p != NULL) {
        printf("%d\n", p->value);
        p = p->next;
    }
    return 0;
}
