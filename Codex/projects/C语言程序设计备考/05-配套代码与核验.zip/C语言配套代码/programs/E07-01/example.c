#include <stdio.h>
struct Student { int number; double score; };
int main(void) {
    struct Student a = {1001, 86.5};
    struct Student b = a;
    b.score += 2.0;
    printf("a: %d %.1f\n", a.number, a.score);
    printf("b: %d %.1f\n", b.number, b.score);
    return 0;
}
