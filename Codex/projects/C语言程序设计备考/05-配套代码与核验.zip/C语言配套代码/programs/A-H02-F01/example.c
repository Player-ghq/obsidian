#include <stdio.h>


int main(void)
{
    int a[4] = {1, 3, 5}, n = 3, value = 3;
    int j = n;
    while (j > 0 && a[j - 1] > value) { a[j] = a[j - 1]; --j; }
    a[j] = value;
    for (int i = 0; i <= n; ++i) printf("%s%d", i ? " " : "", a[i]);
    putchar('\n');
    return 0;
}
