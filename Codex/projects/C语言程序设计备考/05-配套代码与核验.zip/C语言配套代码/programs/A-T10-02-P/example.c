#include <stdio.h>
#include <ctype.h>
int main(void) {
    size_t letters = 0, digits = 0, spaces = 0, other = 0;
    int ch;
    while ((ch = getchar()) != EOF && ch != '\n') {
        if (isalpha((unsigned char)ch)) ++letters;
        else if (isdigit((unsigned char)ch)) ++digits;
        else if (ch == ' ') ++spaces;
        else ++other;
    }
    if (ferror(stdin)) return 1;
    printf("letters=%zu digits=%zu spaces=%zu other=%zu\n", letters, digits, spaces, other);
    return 0;
}
