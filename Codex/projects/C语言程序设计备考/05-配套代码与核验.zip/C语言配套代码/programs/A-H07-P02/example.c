#include <stdio.h>

struct Input { FILE *fp; int previous, count; };
static int next(struct Input *in, int *value)
{
    int status = fscanf(in->fp, "%d", value);
    if (status == EOF) return ferror(in->fp) ? -1 : 0;
    if (status != 1 || *value < -1000 || *value > 1000 || in->count == 30 ||
        (in->count > 0 && *value < in->previous)) return -1;
    in->previous = *value;
    ++in->count;
    return 1;
}

int main(void)
{
    struct Input a = {NULL, 0, 0}, b = {NULL, 0, 0};
    a.fp = fopen("left.txt", "r");
    b.fp = fopen("right.txt", "r");
    if (a.fp == NULL || b.fp == NULL) {
        if (a.fp != NULL) fclose(a.fp);
        if (b.fp != NULL) fclose(b.fp);
        puts("INVALID"); return 1;
    }
    FILE *out = fopen("merged.txt", "w");
    if (out == NULL) { fclose(a.fp); fclose(b.fp); puts("INVALID"); return 1; }
    int x = 0, y = 0, sa = next(&a, &x), sb = next(&b, &y);
    int bad = 0, first = 1;
    while (sa > 0 || sb > 0) {
        if (sa < 0 || sb < 0) { bad = 1; break; }
        int take_a = sb == 0 || (sa > 0 && x <= y);
        if (fprintf(out, "%s%d", first ? "" : " ", take_a ? x : y) < 0) { bad = 1; break; }
        first = 0;
        if (take_a) sa = next(&a, &x);
        else sb = next(&b, &y);
    }
    if (sa < 0 || sb < 0) bad = 1;
    if (!bad && fputc('\n', out) == EOF) bad = 1;
    if (fclose(a.fp) != 0) bad = 1;
    if (fclose(b.fp) != 0) bad = 1;
    if (fclose(out) != 0) bad = 1;
    puts(bad ? "INVALID" : "OK");
    return bad;
}
