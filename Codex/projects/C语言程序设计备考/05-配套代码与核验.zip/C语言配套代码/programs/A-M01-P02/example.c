#include <stdio.h>
struct Record {
    int id;
    int score;
};
int main(int argc, char *argv[])
{
    if (argc != 2) {
        puts("usage");
        return 1;
    }
    FILE *fp = fopen(argv[1], "r");
    if (fp == NULL) {
        puts("invalid");
        return 1;
    }
    struct Record current;
    struct Record best = {0, 0};
    int count = 0, found = 0, failed = 0;
    int status;
    while ((status = fscanf(fp, "%d%d", &current.id, &current.score)) == 2) {
        count++;
        if (count > 100 || current.id < 1 || current.id > 9999 ||
            current.score < 0 || current.score > 100) {
            failed = 1;
            break;
        }
        if (!found || current.score > best.score ||
            (current.score == best.score && current.id < best.id)) {
            best = current;
            found = 1;
        }
    }
    if (status != EOF || ferror(fp)) {
        failed = 1;
    }
    if (fclose(fp) != 0) {
        failed = 1;
    }
    if (failed) {
        puts("invalid");
        return 1;
    }
    if (!found) {
        puts("empty");
    } else {
        printf("%d %d\n", best.id, best.score);
    }
    return 0;
}
