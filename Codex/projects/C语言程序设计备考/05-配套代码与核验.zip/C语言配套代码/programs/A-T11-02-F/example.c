#include <stdio.h>
#define TWICE(x) ((x) * 2)
int main(void) {
    printf("%d\n", 30 / TWICE(2 + 1));
    return 0;
}
