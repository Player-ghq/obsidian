#include <stdio.h>

static void choose(int *a, int *b, int ** best)
{
    *best = *a >= *b ? a : b;
}

int main(void)
{
    int a = 4, b = 9;
    int *best = NULL;
    choose(&a, &b, &best);
    *best += 1;
    printf("%d %d\n", a, b);
    return 0;
}
