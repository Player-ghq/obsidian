#include <stdio.h>
struct Address { int room; };
struct Parcel { char label[16]; struct Address address; };
int main(void) {
    struct Parcel a = {{0}, {0}};
    if (scanf("%15s%d", a.label, &a.address.room) != 2 ||
        a.address.room < 1 || a.address.room > 9999) {
        puts("INVALID"); return 0;
    }
    struct Parcel b = a;
    b.address.room += 1;
    printf("%s %d\n", a.label, a.address.room);
    printf("%s %d\n", b.label, b.address.room);
    return 0;
}
