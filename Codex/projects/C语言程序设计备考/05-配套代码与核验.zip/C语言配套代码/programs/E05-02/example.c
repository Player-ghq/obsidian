#include <stdio.h>
int main(void)
{
    int m[2][3] = {{2, 4, 6}, {1, 3, 5}};
    int (*row)[3] = m;
    printf("first=%d next_row=%d\n", (*row)[0], (*(row + 1))[0]);
    row[1][2] += 10;
    printf("last=%d\n", m[1][2]);
    return 0;
}
