#include <stdio.h>

int main(void)
{
    int score[] = {72, 88, 65, 90, 85};
    size_t count = sizeof score / sizeof score[0];
    int sum = 0;
    int highest = score[0];
    for (size_t i = 0; i < count; ++i) {
        sum += score[i];
        if (score[i] > highest) {
            highest = score[i];
        }
    }
    printf("count=%zu sum=%d average=%.1f highest=%d\n",
           count, sum, (double)sum / count, highest);
    return 0;
}
