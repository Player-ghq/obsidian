#include <stdio.h>

struct Node { int value; struct Node *next; };
static void append_node(struct Node **head, struct Node **tail, struct Node *node)
{
    node->next = NULL;
    if (*tail == NULL) *head = node;
    else (*tail)->next = node;
    *tail = node;
}

int main(void)
{
    struct Node a = {4,NULL}, b = {6,NULL};
    struct Node *head = NULL, *tail = NULL;
    append_node(&head,&tail,&a);
    append_node(&head,&tail,&b);
    printf("%d %d %d\n", head->value, head->next->value, tail->value);
    return 0;
}
