#include <stdio.h>
#include <string.h>
int main(void) {
    const char *a = "zoo";
    const char *b = "apple";
    printf("lengths=%zu,%zu\n", strlen(a), strlen(b));
    int cmp = strcmp(a, b);
    if (cmp < 0) puts("a<b");
    else if (cmp == 0) puts("a=b");
    else puts("a>b");
    printf("equal=%d\n", strcmp("cat", "cat") == 0);
    return 0;
}
