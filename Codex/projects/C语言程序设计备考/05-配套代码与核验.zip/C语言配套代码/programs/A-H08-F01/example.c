#include <stdio.h>


int main(void)
{
    int a[]={4,1,3,2};
    int end=4;
    while (end>1) {
        int last=0;
        for (int i=1;i<end;++i) if (a[i-1]>a[i]) {
            int t=a[i-1]; a[i-1]=a[i]; a[i]=t;
            last = i;
        }
        end = last;
    }
    for (int i=0;i<4;++i) printf("%s%d",i?" ":"",a[i]);
    putchar('\n');
    return 0;
}
