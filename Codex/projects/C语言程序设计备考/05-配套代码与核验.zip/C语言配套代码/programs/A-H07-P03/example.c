#include <stdio.h>
struct Summary { int id, count, sum, maximum; };
int main(int argc, char *argv[])
{
    if (argc != 2) { puts("INVALID"); return 1; }
    FILE *fp = fopen(argv[1], "r");
    if (fp == NULL) { puts("INVALID"); return 1; }
    struct Summary a[20];
    int used = 0, records = 0, id, score, status, bad = 0;
    while ((status = fscanf(fp, "%d%d", &id, &score)) == 2) {
        if (++records > 100 || id < 1 || id > 9999 || score < 0 || score > 100) { bad = 1; break; }
        int j = 0;
        while (j < used && a[j].id != id) ++j;
        if (j == used) {
            if (used == 20) { bad = 1; break; }
            a[used] = (struct Summary){id, 0, 0, score};
            ++used;
        }
        ++a[j].count; a[j].sum += score;
        if (score > a[j].maximum) a[j].maximum = score;
    }
    if (status != EOF || ferror(fp)) bad = 1;
    if (fclose(fp) != 0) bad = 1;
    if (bad) { puts("INVALID"); return 1; }
    for (int i = 1; i < used; ++i) {
        struct Summary key = a[i]; int j = i;
        while (j > 0 && a[j-1].id > key.id) { a[j] = a[j-1]; --j; }
        a[j] = key;
    }
    if (used == 0) puts("EMPTY");
    for (int i = 0; i < used; ++i) printf("%d %d %d %d\n", a[i].id, a[i].count, a[i].sum, a[i].maximum);
    if (fflush(stdout) == EOF) return 1;
    return 0;
}
