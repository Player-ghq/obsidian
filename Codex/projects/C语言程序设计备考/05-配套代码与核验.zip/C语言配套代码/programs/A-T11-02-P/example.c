#include <stdio.h>
static int square(int x) { return x * x; }
int main(void) {
    int n;
    if (scanf("%d", &n) != 1 || n < -100 || n > 100) return 1;
    int result = square(n++);
    printf("square=%d next=%d\n", result, n);
    return 0;
}
