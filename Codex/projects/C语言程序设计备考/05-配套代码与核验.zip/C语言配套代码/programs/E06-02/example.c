#include <stdio.h>
#include <stddef.h>

int total(const int a[], size_t n)
{
    int sum = 0;
    for (size_t i = 0; i < n; ++i) sum += a[i];
    return sum;
}

void add_bonus(int a[], size_t n, int bonus)
{
    for (size_t i = 0; i < n; ++i) a[i] += bonus;
}

int main(void)
{
    int score[] = {60, 70, 80};
    size_t n = sizeof score / sizeof score[0];
    printf("before=%d\n", total(score, n));
    add_bonus(score, n, 5);
    printf("after=%d first=%d\n", total(score, n), score[0]);
    return 0;
}
