#include <stdio.h>
#include <string.h>
int main(void) {
    char line[8];
    if (fgets(line, sizeof line, stdin) == NULL) {
        puts(ferror(stdin) ? "Read error" : "No line");
        return 1;
    }
    size_t n = strlen(line);
    if (n > 0 && line[n - 1] == '\n') line[--n] = '\0';
    else {
        int ch = getchar();
        if (ch != '\n' && ch != EOF) {
            do { ch = getchar(); } while (ch != '\n' && ch != EOF);
            puts("Too long");
            return 1;
        }
        if (ferror(stdin)) return 1;
    }
    printf("length=%zu\n", n);
    for (size_t i = 0; i < n; ++i) putchar((unsigned char)line[i]);
    putchar('\n');
    puts("Done");
    return 0;
}
