#include <stdio.h>
#define DAYS 7

int main(void)
{
    unsigned int stock = 26U;
    long distance = 120L;
    printf("%d %d %d\n", 26, 032, 0x1A);
    printf("%u %ld %.2f %d\n", stock, distance, 1.25e2, DAYS);
    printf("%c %s\n", 'A', "A");
    printf("quote=\" slash=\\\n");
    return 0;
}
