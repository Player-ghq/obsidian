#include <stdio.h>
const int *larger(const int *a, const int *b)
{
    if (*a >= *b) return a;
    return b;
}
int main(void)
{
    int x = 13, y = 8;
    const int *p = larger(&x, &y);
    printf("%d\n", *p);
    return 0;
}
