#include <stdio.h>
int main(void)
{
    for (int row = 1; row <= 2; row++) {
        for (int col = 1; col <= 3; col++) {
            putchar('#');
        }
        putchar('\n');
    }
    return 0;
}
