#include <stdio.h>
static size_t find(const int a[], size_t n, int target) {
    for (size_t i = 0; i < n; ++i) if (a[i] == target) return i;
    return n;
}
int main(void) {
    const int a[] = {8, 2, 8};
    size_t n = sizeof a / sizeof a[0];
    printf("%zu %zu\n", find(a, n, 8), find(a, n, 5));
    return 0;
}
