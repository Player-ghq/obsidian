#include <stdio.h>

struct Student { int id, score, order; };
static int before(struct Student x, struct Student y)
{
    return x.score > y.score || (x.score == y.score && x.id < y.id);
}

int main(void)
{
    int n;
    struct Student a[20];
    if (scanf("%d", &n) != 1 || n < 0 || n > 20) { puts("INVALID"); return 1; }
    for (int i = 0; i < n; ++i) {
        if (scanf("%d%d", &a[i].id, &a[i].score) != 2 || a[i].id < 1 || a[i].id > 9999 || a[i].score < 0 || a[i].score > 100) { puts("INVALID"); return 1; }
        a[i].order = i;
    }
    for (int i = 1; i < n; ++i) {
        struct Student key = a[i];
        int j = i;
        while (j > 0 && before(key, a[j-1])) { a[j] = a[j-1]; --j; }
        a[j] = key;
    }
    if (n == 0) puts("EMPTY");
    for (int i = 0; i < n; ++i) printf("%d %d %d\n", a[i].id, a[i].score, a[i].order);
    return 0;
}
