#include <stdio.h>
static void bubble_sort(int a[], size_t n) {
    for (size_t end = n; end > 1; --end) {
        int changed = 0;
        for (size_t j = 0; j + 1 < end; ++j) {
            if (a[j] > a[j + 1]) {
                int t = a[j]; a[j] = a[j + 1]; a[j + 1] = t;
                changed = 1;
            }
        }
        if (!changed) break;
    }
}
int main(void) {
    int a[] = {6, 2, 5, 2};
    size_t n = sizeof a / sizeof a[0];
    bubble_sort(a, n);
    for (size_t i = 0; i < n; ++i) printf("%s%d", i ? " " : "", a[i]);
    putchar('\n');
    bubble_sort(a, 0);
    return 0;
}
