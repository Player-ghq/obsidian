#include <stdio.h>
int main(void)
{
    int a[] = {5, -2, 8, 1};
    size_t n = sizeof a / sizeof a[0];
    const int *end = a + n;
    int sum = 0;
    for (const int *p = a; p != end; ++p) sum += *p;
    printf("%d\n", sum);
    return 0;
}
