#include <stdio.h>
int twice(int x)
{
    return 2 * x;
}
int main(void)
{
    int (*fn)(int) = twice;
    printf("%d\n", fn(6));
    return 0;
}
