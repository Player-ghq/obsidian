#include <stdio.h>
#ifndef SHOW_TOTAL
#define SHOW_TOTAL 1
#endif
int main(void) {
    int total = 0;
    for (int i = 1; i <= 5; ++i) total += i;
#if SHOW_TOTAL
    printf("total=%d\n", total);
#else
    printf("average=%.1f\n", total / 5.0);
#endif
    return 0;
}
