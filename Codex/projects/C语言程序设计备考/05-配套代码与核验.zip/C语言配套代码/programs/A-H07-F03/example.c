#include <stdio.h>


int main(void)
{
    FILE *a=fopen("one.txt","w");
    if (a==NULL) return 1;
    FILE *b=fopen("two.txt","w");
    if (b==NULL) { fclose(a); return 1; }
    int bad=0;
    if (fputs("A\n",a)==EOF) bad=1;
    if (fputs("B\n",b)==EOF) bad=1;
    if (fclose(a) != 0) bad = 1;
    if (fclose(b) != 0) bad = 1;
    if (!bad) puts("OK");
    return bad;
}
