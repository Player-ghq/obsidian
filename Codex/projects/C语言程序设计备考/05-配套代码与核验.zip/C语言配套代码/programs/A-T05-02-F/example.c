#include <stdio.h>
int main(void)
{
    int m[2][2] = {{8,9},{10,11}};
    int (*p)[2] = m;
    printf("%d\n", p[1][0]);
    return 0;
}
