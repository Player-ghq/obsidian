#include <stdio.h>
#include <ctype.h>
int main(void) {
    const char text[] = "aZ7?";
    for (int i = 0; text[i] != '\0'; ++i) {
        unsigned char c = (unsigned char)text[i];
        printf("%c: alnum=%d alpha=%d digit=%d lower=%d upper=%c\n",
               c, isalnum(c) != 0, isalpha(c) != 0,
               isdigit(c) != 0, islower(c) != 0, toupper(c));
    }
    return 0;
}
