#include <stdio.h>
#include <ctype.h>


int main(void)
{
    FILE *fp=fopen("word.txt","r");
    if (fp==NULL) return 1;
    int ch, inside=0;
    size_t words=0;
    while ((ch=fgetc(fp))!=EOF) {
        if (isspace((unsigned char)ch)) inside=0;
        else if (!inside) { ++words; inside=1; }
    }
    int bad=ferror(fp)!=0;
    if (fclose(fp)!=0) bad=1;
    if (bad) return 1;
    printf("%zu\n",words);
    return 0;
}
