#include <stdio.h>
int main(void) {
    int n, a[20];
    if (scanf("%d", &n) != 1 || n < 0 || n > 20) return 1;
    for (int i = 0; i < n; ++i) if (scanf("%d", &a[i]) != 1) return 1;
    for (int i = 0; i < n; ++i) {
        int maximum = i;
        for (int j = i + 1; j < n; ++j) if (a[j] > a[maximum]) maximum = j;
        int t = a[i]; a[i] = a[maximum]; a[maximum] = t;
    }
    for (int i = 0; i < n; ++i) printf("%s%d", i ? " " : "", a[i]);
    putchar('\n');
    return 0;
}
