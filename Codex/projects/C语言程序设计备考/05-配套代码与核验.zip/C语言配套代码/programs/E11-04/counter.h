#ifndef STUDY_COUNTER_H
#define STUDY_COUNTER_H
extern int total;
void add_score(int value);
int call_count(void);
#endif
