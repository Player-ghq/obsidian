#include <stdio.h>
#include "counter.h"
#include "counter.h"
int main(void) {
    add_score(3);
    add_score(4);
    printf("total=%d calls=%d\n", total, call_count());
    return 0;
}
