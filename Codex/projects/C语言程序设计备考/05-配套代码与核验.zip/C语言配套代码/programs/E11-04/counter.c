#include "counter.h"
int total = 0;
static int calls = 0;
void add_score(int value) { total += value; ++calls; }
int call_count(void) { return calls; }
