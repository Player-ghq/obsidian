#include <stdio.h>


int main(void)
{
    unsigned int x, lo, width, value;
    if (scanf("%u%u%u%u", &x, &lo, &width, &value) != 4 || x > 65535U || lo > 15U || width < 1U || width > 8U || lo + width > 16U) {
        puts("INVALID"); return 1;
    }
    unsigned int mask = (1U << width) - 1U;
    if (value > mask) { puts("INVALID"); return 1; }
    unsigned int old = (x >> lo) & mask;
    unsigned int changed = (x & ~(mask << lo)) | (value << lo);
    printf("%u %u\n", old, changed);
    return 0;
}
