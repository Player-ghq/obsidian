#include <stdio.h>
struct Rectangle { int length; int width; };
int main(void) {
    struct Rectangle r = {0, 0};
    if (scanf("%d%d", &r.length, &r.width) != 2 ||
        r.length < 0 || r.length > 1000 || r.width < 0 || r.width > 1000) {
        puts("INVALID");
        return 0;
    }
    printf("%ld\n", (long)r.length * r.width);
    return 0;
}
