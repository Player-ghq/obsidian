#include <stdio.h>
#include <string.h>
int main(void)
{
    char s[] = "boat";
    s[0] = 'g';
    printf("%s %zu\n", s, strlen(s));
    return 0;
}
