#include <stdio.h>
unsigned long factorial(unsigned int n)
{
    if (n <= 1U) {
        return 1UL;
    }
    return n * factorial(n - 1U);
}
int main(void)
{
    printf("%lu\n", factorial(5U));
    return 0;
}
