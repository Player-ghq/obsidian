#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
int main(int argc, char *argv[])
{
    if (argc > 21) { puts("INVALID"); return 1; }
    long total = 0;
    for (int i = 1; i < argc; ++i) {
        char *end;
        errno = 0;
        long value = strtol(argv[i], &end, 10);
        if (end == argv[i] || *end != '\0' || errno == ERANGE || value < -1000000L || value > 1000000L) {
            puts("INVALID"); return 1;
        }
        total += value;
    }
    printf("%ld\n", total);
    return 0;
}
