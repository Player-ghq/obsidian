#include <stdio.h>
int main(void)
{
    int a = 18;
    int b = -4;
    int *p = &a;
    int *q = &b;
    int temp = *p;
    *p = *q;
    *q = temp;
    printf("a=%d b=%d\n", a, b);
    return 0;
}
