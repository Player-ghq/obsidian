#include <stdio.h>
#define VERBOSE 1
int main(void) {
#if VERBOSE
    puts("details");
#else
    puts("brief");
#endif
    return 0;
}
