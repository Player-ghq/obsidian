#include <stdio.h>
struct Student { int id; int score; };
int main(void) {
    int n;
    struct Student a[5];
    if (scanf("%d", &n) != 1 || n < 1 || n > 5) {
        puts("INVALID"); return 0;
    }
    for (int i = 0; i < n; ++i) {
        a[i].id = i + 1;
        if (scanf("%d", &a[i].score) != 1 || a[i].score < 0 || a[i].score > 100) {
            puts("INVALID"); return 0;
        }
    }
    const struct Student *best = &a[0];
    for (const struct Student *p = a + 1; p < a + n; ++p) {
        if (p->score > best->score) best = p;
    }
    printf("%d %d\n", best->id, best->score);
    return 0;
}
