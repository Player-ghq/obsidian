#include <stdio.h>
unsigned int digit_sum(unsigned int n)
{
    if (n < 10) return n;
    return n % 10 + digit_sum(n / 10);
}
int main(void)
{
    unsigned int a = digit_sum(0);
    unsigned int b = digit_sum(507);
    unsigned int c = digit_sum(1234);
    printf("%u %u %u\n", a, b, c);
    return 0;
}
