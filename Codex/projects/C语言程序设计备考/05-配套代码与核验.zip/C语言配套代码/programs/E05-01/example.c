#include <stdio.h>
int main(void)
{
    int x = 10;
    int y = 30;
    int *p = &x;
    *p += 5;
    p = &y;
    *p = x + 2;
    printf("x=%d y=%d target=%d\n", x, y, *p);
    return 0;
}
