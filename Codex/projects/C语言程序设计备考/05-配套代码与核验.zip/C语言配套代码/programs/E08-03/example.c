#include <stdio.h>
#include <stdlib.h>
struct Node { int value; struct Node *next; };
static void destroy(struct Node *head) {
    while (head != NULL) {
        struct Node *next = head->next;
        free(head);
        head = next;
    }
}
static int append(struct Node **head, struct Node **tail, int value) {
    struct Node *node = malloc(sizeof *node);
    if (node == NULL) return 0;
    node->value = value;
    node->next = NULL;
    if (*tail == NULL) *head = node;
    else (*tail)->next = node;
    *tail = node;
    return 1;
}
static void print_list(const struct Node *head) {
    if (head == NULL) { puts("EMPTY"); return; }
    for (const struct Node *p = head; p != NULL; p = p->next) {
        printf("%d%s", p->value, p->next == NULL ? "\n" : " ");
    }
}
static int insert_at(struct Node **head, int position, int value) {
    if (position < 0) return 0;
    struct Node **link = head;
    for (int i = 0; i < position; ++i) {
        if (*link == NULL) return 0;
        link = &(*link)->next;
    }
    struct Node *node = malloc(sizeof *node);
    if (node == NULL) return -1;
    node->value = value;
    node->next = *link;
    *link = node;
    return 1;
}
int main(void) {
    struct Node *head = NULL, *tail = NULL;
    if (!append(&head, &tail, 10) || !append(&head, &tail, 30)) {
        puts("ALLOC_FAIL"); destroy(head); return 1;
    }
    int status = insert_at(&head, 1, 20);
    if (status != 1) {
        puts(status < 0 ? "ALLOC_FAIL" : "BAD_POSITION");
        destroy(head); return status < 0 ? 1 : 0;
    }
    print_list(head);
    destroy(head);
    return 0;
}
