#include <stdio.h>
#include <limits.h>
int main(void) {
    unsigned int base;
    char text[65];
    if (scanf("%u %64s", &base, text) != 2 || base < 2 || base > 16) return 1;
    unsigned long long value = 0;
    for (size_t i = 0; text[i] != '\0'; ++i) {
        unsigned int digit;
        if (text[i] >= '0' && text[i] <= '9') digit = (unsigned)(text[i] - '0');
        else if (text[i] >= 'A' && text[i] <= 'F') digit = (unsigned)(text[i] - 'A') + 10;
        else { puts("Invalid digit"); return 1; }
        if (digit >= base) { puts("Invalid digit"); return 1; }
        if (value > (ULLONG_MAX - digit) / base) { puts("Overflow"); return 1; }
        value = value * base + digit;
    }
    printf("decimal=%llu\n", value);
    return 0;
}
