#include <stdio.h>
#include <string.h>

struct Tag { char name[8]; int id; };

int main(void)
{
    struct Tag a[3] = {{"pear",3},{"apple",1},{"kiwi",2}};
    for (int i = 1; i < 3; ++i) {
        struct Tag key = a[i];
        int j = i;
        while (j > 0 && strcmp(a[j-1].name, key.name) > 0) { a[j] = a[j-1]; --j; }
        a[j] = key;
    }
    for (int i = 0; i < 3; ++i) printf("%s %d\n", a[i].name, a[i].id);
    return 0;
}
