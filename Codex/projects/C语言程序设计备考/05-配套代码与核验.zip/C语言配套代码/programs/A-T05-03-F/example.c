#include <stdio.h>
int main(void)
{
    int x = 4, y = 9;
    int *ref[2] = {&x, &y};
    printf("%d\n", *ref[1]);
    return 0;
}
