#include <stdio.h>
int main(void)
{
    int m[3][3] = {{2,1,0},{4,5,6},{7,8,9}};
    int sum = 0;
    for (size_t i = 0; i < 3; ++i) sum += m[i][i];
    printf("%d\n", sum);
    return 0;
}
