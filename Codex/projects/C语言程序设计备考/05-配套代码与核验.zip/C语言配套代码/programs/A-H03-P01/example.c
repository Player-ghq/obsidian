#include <stdio.h>

static void reverse(int *first, int *last)
{
    while (first < last) {
        --last;
        if (first >= last) break;
        int t = *first;
        *first++ = *last;
        *last = t;
    }
}

int main(void)
{
    int a[30], n, k;
    if (scanf("%d%d", &n, &k) != 2 || n < 0 || n > 30 || k < 0 || k > 1000) { puts("INVALID"); return 1; }
    for (int i = 0; i < n; ++i) if (scanf("%d", &a[i]) != 1) { puts("INVALID"); return 1; }
    if (n > 0) {
        k %= n;
        reverse(a, a + n);
        reverse(a, a + k);
        reverse(a + k, a + n);
    }
    for (int i = 0; i < n; ++i) printf("%s%d", i ? " " : "", a[i]);
    putchar('\n');
    return 0;
}
