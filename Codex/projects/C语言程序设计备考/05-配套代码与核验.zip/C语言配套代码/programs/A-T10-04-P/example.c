#include <stdio.h>
#include <string.h>
int main(void) {
    FILE *in = fopen("log.txt", "r");
    if (in == NULL) return 1;
    FILE *out = fopen("errors.txt", "w");
    if (out == NULL) { fclose(in); return 1; }
    char line[80];
    size_t hits = 0;
    int bad = 0;
    while (fgets(line, sizeof line, in) != NULL) {
        if (strstr(line, "error") != NULL) {
            if (fputs(line, out) == EOF) { bad = 1; break; }
            ++hits;
        }
    }
    if (ferror(in)) bad = 1;
    if (fclose(in) == EOF) bad = 1;
    if (fclose(out) == EOF) bad = 1;
    if (bad) return 1;
    printf("hits=%zu\n", hits);
    return 0;
}
