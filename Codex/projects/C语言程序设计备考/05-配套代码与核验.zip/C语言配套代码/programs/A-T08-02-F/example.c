#include <stdio.h>
#include <stdlib.h>
struct Node { int value; struct Node *next; };
static void destroy(struct Node *head) {
    while (head != NULL) {
        struct Node *next = head->next;
        free(head);
        head = next;
    }
}
static int append(struct Node **head, struct Node **tail, int value) {
    struct Node *node = malloc(sizeof *node);
    if (node == NULL) return 0;
    node->value = value;
    node->next = NULL;
    if (*tail == NULL) *head = node;
    else (*tail)->next = node;
    *tail = node;
    return 1;
}
int main(void) {
    struct Node *head = NULL, *tail = NULL;
    if (!append(&head, &tail, 2) || !append(&head, &tail, 6)) {
        puts("ALLOC_FAIL"); destroy(head); return 1;
    }
    int count = 0;
    const struct Node *p = head;
    while (p != NULL) {
        ++count;
        p = p->next;
    }
    printf("count=%d\n", count);
    destroy(head);
    return 0;
}
