#include <stdio.h>
int main(void)
{
    unsigned int flags = 0U;
    flags |= (1U << 3);
    printf("%u\n", flags);
    return 0;
}
