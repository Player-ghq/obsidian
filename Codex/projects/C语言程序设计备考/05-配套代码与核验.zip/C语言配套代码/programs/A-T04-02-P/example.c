#include <stdio.h>
int main(void)
{
    int a[2][3] = {{1,4,7},{2,5,8}};
    int b[3][2] = {{0}};
    for (size_t r = 0; r < 2; ++r) {
        for (size_t c = 0; c < 3; ++c) b[c][r] = a[r][c];
    }
    for (size_t r = 0; r < 3; ++r) {
        for (size_t c = 0; c < 2; ++c) {
            printf("%s%d", c == 0 ? "" : " ", b[r][c]);
        }
        putchar('\n');
    }
    return 0;
}
