#include <stdio.h>
int main(void)
{
    FILE *fp = fopen("input.txt", "r");
    if (fp == NULL) {
        return 1;
    }
    int ch;
    int failed = 0;
    while ((ch = fgetc(fp)) != EOF) {
        if (putchar(ch) == EOF) {
            failed = 1;
            break;
        }
    }
    if (ferror(fp)) {
        failed = 1;
    }
    if (fclose(fp) != 0) {
        failed = 1;
    }
    if (fflush(stdout) == EOF) {
        failed = 1;
    }
    return failed;
}
