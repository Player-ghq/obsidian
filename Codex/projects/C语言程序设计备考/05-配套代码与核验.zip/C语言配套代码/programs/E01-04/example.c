#include <stdio.h>

int total_calls = 0;
static int file_marker = 9;

void visit(void)
{
    auto int local = 0;
    static int saved = 0;
    local++;
    saved++;
    total_calls++;
    printf("%d %d %d\n", local, saved, total_calls);
}

int main(void)
{
    visit();
    visit();
    printf("marker=%d\n", file_marker);
    return 0;
}
