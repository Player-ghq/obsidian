#include <stdio.h>
#define LIMIT 3
#ifndef LABEL
#define LABEL "C17"
#endif
int main(void) {
    printf("%s:", LABEL);
    for (int i = 1; i <= LIMIT; ++i) printf(" %d", i);
    putchar('\n');
    return 0;
}
