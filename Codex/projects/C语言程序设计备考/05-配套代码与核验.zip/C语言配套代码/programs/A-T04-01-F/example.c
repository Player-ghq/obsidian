#include <stdio.h>
int main(void)
{
    int a[] = {3, 8, 0, 5, 12};
    int count = 0;
    for (size_t i = 0; i < sizeof a / sizeof a[0]; ++i) {
        if (a[i] % 2 == 0) ++count;
    }
    printf("%d\n", count);
    return 0;
}
