#include <stdio.h>

static int add(int a, int b) { return a + b; }
static int maximum(int a, int b) { return a > b ? a : b; }

int main(void)
{
    int (*ops[2])(int, int) = {add, maximum};
    printf("%d %d\n", ops[0](6,4), ops[1](6, 4));
    return 0;
}
