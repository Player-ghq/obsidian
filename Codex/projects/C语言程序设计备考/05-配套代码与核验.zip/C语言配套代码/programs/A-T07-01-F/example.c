#include <stdio.h>
struct Book { int pages; double price; };
int main(void) {
    struct Book b = {120, 18.0};
    b.pages = 150;
    printf("%.1f\n", b.price);
    return 0;
}
