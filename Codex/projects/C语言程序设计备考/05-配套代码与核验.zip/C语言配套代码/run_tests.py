from pathlib import Path
import subprocess, tempfile, json, os, sys, shutil, fnmatch
base=Path(__file__).resolve().parent
compiler=os.environ.get('CC','clang')
if shutil.which(compiler) is None:
    raise SystemExit('需要安装Clang，或设置CC为可用的GCC命令名。')
cases=json.loads((base/'cases.json').read_text())
selected=sys.argv[1] if len(sys.argv)>1 else None
if selected: cases=[c for c in cases if fnmatch.fnmatchcase(c['id'], selected)]
if not cases: raise SystemExit('没有匹配该编号的测试。')
compiled={};passed=0
with tempfile.TemporaryDirectory(prefix='c-study-') as root:
    root=Path(root)
    for index,c in enumerate(cases):
        key=(c['id'],tuple(c.get('cflags',[])))
        if key not in compiled:
            folder=base/'programs'/c['id'];exe=root/('program-'+str(len(compiled)))
            cmd=[compiler,'-std=c17','-Wall','-Wextra','-Wpedantic','-Werror',*key[1],*[str(p) for p in sorted(folder.glob('*.c'))],'-lm','-o',str(exe)]
            p=subprocess.run(cmd,capture_output=True,text=True)
            if p.returncode: raise SystemExit(p.stderr)
            compiled[key]=exe
        with tempfile.TemporaryDirectory(dir=root) as d:
            for name,content in c.get('files',{}).items():
                p=Path(d)/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content)
            p=subprocess.run([str(compiled[key]),*c.get('args',[])],input=c.get('stdin',''),capture_output=True,text=True,cwd=d,timeout=8,env=dict(os.environ,LC_ALL='C'))
            okay=(p.returncode,p.stdout,p.stderr)==(c.get('exit',0),c.get('stdout',''),c.get('stderr',''))
            for name,content in c.get('output_files',{}).items():
                f=Path(d)/name;okay=okay and f.exists() and f.read_text()==content
            for name,content in c.get('output_files_hex',{}).items():
                f=Path(d)/name;okay=okay and f.exists() and f.read_bytes()==bytes.fromhex(content)
            if not okay:raise SystemExit(str({'id':c['id'],'expected':c,'actual':(p.returncode,p.stdout,p.stderr)}))
            passed+=1
print(f'{passed}/{len(cases)} tests passed; {len(compiled)} builds')
